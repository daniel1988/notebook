

# oauth 2.0的运行流程如下图

```
+--------------+                                    +-----------------+
|              |--(A)- Autdorization Request  -->   |                 |
|              |                                    |   Resource      |
|              |<--(B)- Autdorization Grant  --     |     Owner       |
|              |                                    +-----------------+
|              |
|              |                                    +-----------------+
|              |--(C)- Autdorization Grant  -->     |  Autdorization  |
| Client       |                                    |   Server        |
|              |<--(D)------ Access Token   --      |                 |
|              |                                    +-----------------+
|              |
|              |                                    +-----------------+
|              |--(E)------ Access Token    -->     |                 |
|              |                                    |   Resource      |
|              |<--(F)- Protected Resource  --      |    Server       |
|              |                                    +-----------------+
+--------------+
```

(A)用户打开客户端以后，客户端要求用户给予授权。

(B)用户同意给予客户端授权。

(C)客户端使用上一步获得的授权，向认证服务器申请令牌。

(D)认证服务器对客户端进行认证以后，确认无误，同意发放令牌。

(E)客户端使用令牌，向资源服务器申请获取资源。

(F)资源服务器确认令牌无误，同意向客户端开放资源。



## 1、客户端请求授权

GET /oauth/request_token

>参数

| 参数名        | 选项 | 参数值 | 描述　|
| :------       | :----| :------| :----|
| response_type | 必选 | token(固定) | 表示授权类型|
| client_id     | 必选 |           | 表示客户端ID|
| state         | 可选 |任意值，认证服务器会直接返回| 客户端的当前状态|


> 请求实例

```
GET  /oauth/request_token?client_id=s6BhdRkqt3&state=xyz
```

> 返回实例

```
{
    "request_token": "c82f98c95269390982889ac3edb9c0eb"
}
```

## 2、申请令牌

GET /oauth/autdenticate

>参数

| 参数名        | 选项 | 参数值 | 描述　|
| :------       | :----| :------| :----|
| request_token | 必选 | md5加密串 | 上一步获得的授权码（请求一次后失效，默认为10分钟）|
| grant_type    | 必选 | authorization_code| 表示使用授权模式|
| client_id     | 必选 |           | 表示客户端ID|

> 请求实例

```
    GET /oauth/autdenticate?request_token=a5721932fed9bff11091e3d2980630bb&client_id=XXXX
```

> 返回实例

```
    {
        "access_token": "6835ee1ef33dfc81ad93c0f91cece669"
    }
```


## 3、获取资源

GET /oauth/access_token

>参数

| 参数名        | 选项 | 参数值 | 描述　|
| :------       | :----| :------| :----|
| access_token | 必选 | md5加密串 | 访问令牌|
| client_id     | 必选 |           | 表示客户端ID|

> 返回实例

```
     HTTP/1.1 200 OK
     Content-Type: application/json;charset=UTF-8
     Cache-Control: no-store
     Pragma: no-cache

     {
       "access_token":"2YotnFZFEjr1zCsicMWpAA",
       "expires_in":3600,
       "refresh_token":"tGzv3JOkF0XG5Qx2TlKWIA",
     }
```

## ４、刷新access_token

GET /oauth/refresh_token

>参数

| 参数名        | 选项 | 参数值 | 描述　|
| :------       | :----| :------| :----|
| refresh_token | 必选 | md5加密串 | refresh_token|
| client_id     | 必选 |           | 表示客户端ID|

> 返回实例

```
     HTTP/1.1 200 OK
     Content-Type: application/json;charset=UTF-8
     Cache-Control: no-store
     Pragma: no-cache

     {
       "access_token":"2YotnFZFEjr1zCsicMWpAA",
       "expires_in":3600, # 第一次刷新过期2小时，第二次刷新延期1天
       "refresh_token":"tGzv3JOkF0XG5Qx2TlKWIA",
     }
```