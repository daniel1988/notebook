<?php

/**
 * 基础控制器类
 */
class ControllerBase extends \Phalcon\Mvc\Controller
{
    /**
     * 默认语言类型
     *
     * @var string
     */
    public $lang = 'zh-cn';

    /**
     * 支持的语言类型
     *
     * @var array
     */
    public $langs = null;

    /**
     * 当前 module 名称
     *
     * @var string
     */
    public $module = null;

    /**
     * 当前 controller 名称
     *
     * @var string
     */
    public $controller = null;

    /**
     * 当前 action 名称
     *
     * @var string
     */
    public $action = null;

    /**
     * Action 完成前执行
     */
    public function beforeExecuteRoute($dispatcher)
    {

        $this->module     = $dispatcher->getModuleName();
        $this->controller = camel($dispatcher->getControllerName());
        $this->action     = $dispatcher->getActionName();


        // 赋值到视图中
        $this->view->setVars([
            'module'     => $this->module,
            'controller' => $this->controller,
            'action'     => $this->action,
        ]);

        // AJAX 模式下，仅显示 action 视图
        if ($this->request->isAjax() || $this->request->has('modal')) {
            $this->view->setRenderLevel(Phalcon\Mvc\View::LEVEL_ACTION_VIEW);
        }

        return true; // false 时停止执行
    }

    /**
     * 初始化方法
     *
     */
    public function initialize() {}

    /**
     * Action 完成后执行
     */
    public function afterExecuteRoute($dispatcher)
    {

    }

    /**
     * 页面重定向
     *
     * @param string  $location
     * @param boolean $external
     * @param integer $code
     */
    public function redirect($location, $external = false, $code = 302)
    {
        return $this->response->redirect($location, $external, $code)->sendHeaders();
    }



    /**
     * 简化 dispatcher->forward 方法，可同时指定参数
     *
     *     $this->forward(array('controller' => 'user', 'action' => 'login'), array('email' => 'my@mail.com'));
     *     $this->forward('user/login', array('email' => 'my@mail.com'));
     *
     * @param string|array $forward
     * @param array        $params
     */
    public function forward($forward, array $params = [])
    {
        $this->dispatcher->setParams($params);

        if (!is_array($forward)) {
            $array = explode('/', $forward);
            switch (true) {
                case count($array) === 3:
                    $forward = [
                        'module'     => $array[0],
                        'controller' => $array[1],
                        'action'     => $array[2],
                    ];
                    break;
                case count($array) === 2:
                    $forward = [
                        'controller' => $array[0],
                        'action'     => $array[1],
                    ];
                    break;
                case count($array) === 1:
                    $forward = [
                        'controller' => $array[0],
                        'action'     => 'index',
                    ];
                    break;
                default:
                    throw new InvalidArgumentException('Invalid forward arguments');
            }
        }

        return $this->dispatcher->forward($forward);
    }

    /**
     * [jsonRet description]
     * @param  [type]  $data [description]
     * @param  integer $flag [description]
     * @return [type]        [description]
     */
    public function jsonRet( $data, $flag=0 )
    {

        $this->response->setHeader('Cache-Control', 'no-store');
        $this->response->setHeader('Pragma', 'no-cache');
        $this->response->setHeader('Authorization', 'reqest_token:xxx;access_token:oooo');
        $this->response->setHeader('Content-type', 'application/json;charset=UTF-8');
        $this->response->setJsonContent($data,
            defined('JSON_PRETTY_PRINT') ? JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES : null
        );
        $this->response->send();
        exit;
    }
}
