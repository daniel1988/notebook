<?php

class OauthController extends ControllerBase
{

    /**
     * 客户端请求授权
     * @return [type] [description]
     */
    public function requestTokenAction()
    {
        $result = [
            'request_token' => md5(uniqid() + time()),
            'state'         => '1'
        ];

        return $this->jsonRet($result);
    }

    /**
     * 客户端向服务器申请令牌
     * @return [type] [description]
     */
    public function authenticateAction()
    {
        $result = [
            'access_token'  => md5(uniqid() + time()),
        ];
        return $this->jsonRet($result);
    }


    /**
     * 客户端使用令牌申请服务器资源
     * @return [type] [description]
     */
    public function accessTokenAction()
    {
        $result = [
            'access_token'  => md5(uniqid() + time()),
            'expire_in'     => 3600,
            'refresh_token' => md5(uniqid() + time())
        ];
        return $this->jsonRet($result);

    }

    /**
     * 刷新令牌时间
     * @return [type] [description]
     */
    public function refreshTokenAction()
    {
        return $this->jsonRet(['access_token'=> md5(uniqid() + time())]);
    }
}