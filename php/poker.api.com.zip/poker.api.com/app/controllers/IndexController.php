<?php

use Phalcon\Mvc\Controller;
use Phalcon\Mvc\View;

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        echo 'indexAction----';
        $this->view->setRenderLevel(View::LEVEL_NO_RENDER);
    }

    public function testAction()
    {
        echo 'testAction';
        $this->view->setRenderLevel(View::LEVEL_NO_RENDER);
    }

    public function requestTokenAction()
    {


        echo  $this->jsonRet(['request_token'=> md5(uniqid() + time())]);
        exit;
    }
}
