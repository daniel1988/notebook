<?php
/**
 * 数据库表名配置
 */
return [
    /**
     * 默认库为 e4max_user_info
     * 如果为默认库请勿指定 database
     * phalcon 可能会自动添加 default database
     */
    'dbE4max' => [
        'userinfo' => function ($uid) {
            return 't_user_info_' . fmod($uid, 100);
        },
        'login2uid' => 't_mt4login_2_uid',
        'generator' => 't_uid_generator',
        'bonus' => 'e4max_bonus_info.t_bonus_history',
    ],
];
