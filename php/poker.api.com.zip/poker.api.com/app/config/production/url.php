<?php
return [
    'center' => 'https://center.formaxoa.com/',
    'formax' => 'http://fx.jrq.com/',
    'copymaster' => 'https://copyfx.jrq.com/',
    'qrcode' => [
        'p2p' => 'http://mobile.jrq.com/user/newten?lang=zh-cn&fromid=',
        'forbag' => 'http://forbag.jrq.com/mobile/open/basic?platform=forbag&fromid=',
        'forex' => 'http://agent.jrq.com/user/register?key=',
    ],
    'forbag' => 'http://forbag.jrq.com/',
    'cslist' => 'http://cs.formaxoa.com/api/issue/get-list/?key=cs@2016',
    'csGetDetail' => 'http://cs.formaxoa.com/api/issue/get-detail/?key=cs@2016',
];
