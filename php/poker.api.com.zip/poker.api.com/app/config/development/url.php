<?php
return [
    'center' => 'http://dev.center.formaxoa.com/',
    // 'center'=>'http://test.center.eformax.com/',
    'formax' => 'http://fx.jrq.com/',
    'copymaster' => 'http://copyfx.jrq.com/',
    'qrcode' => [
        'p2p' => 'http://mobile.jrq.com/user/newten?lang=zh-cn&fromid=',
        'forbag' => 'http://forbag.jrq.com/mobile/open/basic?platform=forbag&fromid=',
        'forex' => 'http://agent.jrq.com/user/register?key=',
    ],
    'forbag' => 'http://forbag.jrq.com/',
    'cslist' => 'http://restructure.cs.testing.formaxoa.com/api/issue/get-list/?key=cs@2016',
    'csGetDetail' => 'http://restructure.cs.testing.formaxoa.com/api/issue/get-detail/?key=cs@2016',
];
