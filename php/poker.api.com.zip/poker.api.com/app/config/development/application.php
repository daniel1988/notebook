<?php

return [
    /**
     * @link http://docs.phalconphp.com/zh/latest/reference/loader.html
     */
    'loader' => [
        'dirs' => [
            'controllersDir' => APP_PATH . '/controllers/',
            'modelsDir' => APP_PATH . '/models/',
            'libraryDir' => APP_PATH . '/library/',
            'pluginsDir' => APP_PATH . '/plugins/',
        ],
        'namespaces' => [
        ],
        'prefixes' => [
        ],
    ],

    /**
     * @link http://docs.phalconphp.com/zh/latest/reference/db.html
     * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Db_Adapter_Pdo_Mysql.html
     */
    'databases' => include __DIR__ . '/databases.php',

    /**
     * @link http://docs.phalconphp.com/zh/latest/reference/models.html#models-meta-data
     * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Model_MetaData.html
     */
    'models' => [
        'metadata' => [
            'adapter' => 'files',
            'options' => [
                'lifetime' => 86400,
                'prefix' => 'newcrm',
                'metaDataDir' => DATA_PATH . '/metadata/',
            ],
        ],
    ],

    /**
     * @link http://docs.phalconphp.com/zh/latest/reference/url.html
     * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Url.html
     */
    'url' => [
        'baseUri' => '/',
        'staticBaseUri' => '/',
    ],

    /**
     * @link http://docs.phalconphp.com/zh/latest/reference/views.html
     * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_View.html
     */
    'view' => [
        'viewsDir' => APP_PATH . '/views/',
    ],

    /**
     * @link http://docs.phalconphp.com/zh/latest/reference/cache.html
     */
    'cache' => [
        'frontendOptions' => [
            'lifetime' => 86400, // 1 天
        ],
        'backendOptions' => [
            'prefix' => 'newcrm',
            'host' => '127.0.0.1',
            'port' => 11211,
        ],
    ],

    /**
     * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Session.html
     * @link http://docs.phalconphp.com/zh/latest/reference/session.html
     * @link https://github.com/phalcon/incubator/blob/1.3.0/Library/Phalcon/Session/Adapter/README.md
     */
    'session' => [
        'adapter' => 'memcache',
        'options' => [
            'host' => '127.0.0.1',
            'port' => 11212,
            'lifetime' => 86400,
            'prefix' => 'newcrm',
            'persistent' => false,
        ],
    ],

    /**
     * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Http_Response_Cookies.html
     * @link http://docs.phalconphp.com/zh/latest/reference/cookies.html
     */
    'cookies' => [
        'lifetime' => 604800,  // 默认生存周期 7 天，单位：秒
        'path' => '/',         // Cookie 存储路径
        'domain' => HTTP_HOST, // Cookie 域名范围
        'secure' => false,     // 是否启用 https 连接传输
        'httponly' => false,   // 仅允许 http 访问，禁止 javascript 访问
        'encrypt' => false,    // 是否启用 crypt 加密
    ],

    /**
     * 多语言设置
     */
    'i18n' => [
        'key' => 'lang',                   // $_REQUEST 键名 & Cookie 名
        'default' => 'zh-cn',              // 默认语言
        'directory' => APP_PATH . '/i18n', // 语言包所在目录
        'aliases' => [                     // 语言别名，因为 \Phalcon\Http\Request::getBestLanguage 有可能获得缩写
            'zh-cn' => ['zh', 'cn', 'tw', 'zh-tw', 'hk', 'zh-hk'],
            'en-us' => ['en', 'us'],
        ],
        'supports' => [
            'en-us' => 'English',
            'zh-cn' => '中文',
        ],
        'import' => ['acl'], // 默认加载的语言包
    ],

    /**
     * 验证码设置
     *
     * @link https://github.com/Gregwar/Captcha
     */
    'captcha' => [
        'width' => 100,
        'height' => 40,
    ],

    /**
     * @see http://docs.phalconphp.com/en/latest/reference/crypt.html
     * @see http://docs.phalconphp.com/en/latest/api/Phalcon_Crypt.html
     */
    'crypt' => [
        'salt' => 'v3L%=+',
    ],
];
