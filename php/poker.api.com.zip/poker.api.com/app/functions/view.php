<?php

/**
 * VIEW 相关函数
 */
/**
 * 获取视图内容
 *
 * @link   http://docs.phalconphp.com/zh/latest/reference/views.html
 * @link   http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_View.html
 *
 * @return string
 */
function get_content()
{
    return S('view')->getContent();
}

/**
 * 判断视图是否存在
 *
 * @link   http://docs.phalconphp.com/zh/latest/reference/views.html
 *
 * @param  string       $viewFile
 * @param  string|array $suffixes
 * @return boolean
 */
function has_view($viewFile, $suffixes = null)
{
    $file = S('view')->getViewsDir() . $viewFile;

    if ($suffixes === null) {
        $suffixes = ['phtml', 'volt'];
    } elseif (!is_array($suffixes)) {
        $suffixes = [$suffixes];
    }

    foreach ($suffixes as $suffix) {
        if (is_file($file . '.' . $suffix)) {
            return true;
        }
    }

    return false;
}

/**
 * 加载局部视图
 *
 * @link   http://docs.phalconphp.com/zh/latest/reference/views.html
 * @link   http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_View.html
 *
 * @param  string   $partialPath
 * @param  array    $params
 * @return string
 */
function partial_view($partialPath, array $params = null)
{
    return S('view')->partial($partialPath, $params);
}

/**
 * 选择不同的视图来渲染，并做为最后的 controller/action 输出
 *
 * @link   http://docs.phalconphp.com/zh/latest/reference/views.html
 * @link   http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_View.html
 *
 * @param  string   $renderView
 * @return string
 */
function pick_view($renderView)
{
    return S('view')->pick($renderView);
}

/**
 * 为视图设定值
 *
 * @link  http://docs.phalconphp.com/zh/latest/reference/views.html
 * @link  http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_View.html
 *
 * @param string|array $key
 * @param mixed        $value
 */
function set_var($key, $value = null)
{
    if (is_array($key)) {
        S('view')->setVars($key, true);
    } else {
        S('view')->setVar($key, $value);
    }
}

/**
 * 获取视图设定的值
 *
 * @link  http://docs.phalconphp.com/zh/latest/reference/views.html
 * @link  http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_View.html
 *
 * @param string $key
 * @param mixed  $default
 */
function get_var($key, $default = null)
{
    return isset(S('view')->$key) ? S('view')->$key : $default;
}

/**
 * 根据值的结果，显示 yes or no 的图标
 *
 * @param  string   $bool
 * @param  string   $text
 * @return string
 */
function bool_icon($bool, $trueText = '', $falseText = '')
{
    return sprintf(
        '<span class="text text-%s"><i class="fa fa-%s"></i> %s</span>',
        $bool ? 'success' : 'danger',
        $bool ? 'check' : 'times',
        $bool ? $trueText : $falseText
    );
}

/**
 * 根据业务范围，格式化显示其文字
 *
 * @param  string   $bool
 * @param  string   $text
 * @return string
 */
function business_scopes($scopes)
{
    if (!is_array($scopes)) {
        $scopes = explode(',', $scopes);
    }

    foreach ($scopes as &$scope) {
        $scope = __("scope.$scope");
    }

    return implode(', ', $scopes);
}
