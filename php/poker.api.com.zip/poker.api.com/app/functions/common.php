<?php

/**
 * 基础公共函数
 */
/**
 * 加载函数库
 *
 *     load_functions('tag', ...)
 *     load_functions(array('tag', ...))
 *
 * @param string|array $names
 */
function load_functions($names)
{
    static $cached = ['common'];

    if (func_num_args() > 1) {
        $names = func_get_args();
    } elseif (!is_array($names)) {
        $names = [$names];
    }

    $names = array_map('strtolower', $names);

    foreach ($names as $name) {
        if (!isset($cached[$name])) {
            $file = APP_PATH . "/functions/{$name}.php";
            if (is_file($file)) {
                require_once $file;
            }
        }
    }
}

/**
 * 项目更新时间
 *
 * @return integer
 */
function app_update_time()
{
    static $time = null;

    if (null === $time) {
        if ($cache = cache_get('app_update_time')) {
            return $cache;
        }

        $time = time();
        cache_save('app_update_time', $time);
    }

    return $time;
}

/**
 * 将当前环境转换为字符串
 */
function env_str()
{
    switch (true) {
        case PRODUCTION:
            return 'production';
        case STAGING:
            return 'staging';
        case TESTING:
            return 'testing';
        default:
            return 'development';
    }
}

/**
 * 加载配置文件数据
 *
 *     config('database')
 *     config('database.default.adapter')
 *
 * @param  string  $name
 * @return mixed
 */
function config($name, $default = null)
{
    static $cached = [];

    // 移除多余的分隔符
    $name = trim($name, '.');

    if (isset($cached[$name])) {
        return null === $cached[$name] ? $default : $cached[$name];
    }

    // 获取配置名及路径
    if (strpos($name, '.') === false) {
        $paths = [];
        $filename = $name;
    } else {
        $paths = explode('.', $name);
        $filename = array_shift($paths);
    }

    if (isset($cached[$filename])) {
        $data = $cached[$filename];
    } else {
        // 默认优先查找 php 数组类型的配置
        // 查找不到时，根据支持的配置类型进行查找 (注意类型的优先顺序)
        $drivers = [
            'yaml' => '\Phalcon\Config\Adapter\Yaml',
            'json' => '\Phalcon\Config\Adapter\Json',
            'ini' => '\Phalcon\Config\Adapter\Ini',
        ];

        // 当前配置环境路径
        $path = APP_PATH . '/config/' . env_str();

        $file = "$path/$filename.php";
        if (is_file($file)) {
            $data = include $file;
        } else {
            // 查找配置文件
            $data = null;
            foreach ($drivers as $ext => $class) {
                $file = "$path/$filename.$ext";
                if (is_file($file)) {
                    $data = new $class($file);
                    break;
                }
            }
        }

        if (is_array($data)) {
            $data = new \Phalcon\Config($data);
        }

        // 缓存文件数据
        $cached[$filename] = $data;
    }

    // 支持路径方式获取配置，例如：config('file.key.subkey')
    foreach ($paths as $key) {
        $data = isset($data->{$key}) ? $data->{$key} : null;
    }

    // 缓存数据
    $cached[$name] = $data;

    return null === $cached[$name] ? $default : $cached[$name];
}

/**
 * 简化 \Phalcon\Di::getDefault()->getShared($service)
 *
 *     service('url')
 *     service('db')
 *     ...
 *
 * @link   http://docs.phalconphp.com/zh/latest/api/Phalcon_DI.html
 *
 * @param  string  $service
 * @return mixed
 */
function service($service)
{
    return \Phalcon\DI::getDefault()->getShared($service);
}

/**
 * 实例化一个 model
 *
 *     model('user_data')
 *     model('UserData')
 *
 * @param  string   $name
 * @return object
 */
function model($name)
{
    // 格式化类名
    $class = implode('_', array_map('ucfirst', explode('_', $name)));

    // 调用实例
    if (method_exists($class, 'instance')) {
        return $class::instance();
    }

    return new $class(Phalcon\DI::getDefault());
}

/**
 * 获取数据库表名
 *
 *     table('dbE4max.user_info', 20131) // e4max_user_info.t_user_info_31
 *     table('db232.customer') // fuyi_tradeweb.t_customers
 *
 * @param  string   $name
 * @return string
 */
function table($name)
{
    if ($table = config("tables.$name")) {
        if (is_callable($table)) {
            $args = func_get_args();
            array_shift($args);
            $table = call_user_func_array($table, $args);
        }

        return $table;
    }

    throw new Exception("Unknown table name: $name");
}

/**
 * 语言转换
 *
 *     // data: array('welcome' => 'Hello, :name')
 *     __('welcome', array(':name' => 'zhouyl')) // Hello, zhouyl
 *
 * @param  string   $string 要转换的字符串，默认传入中文
 * @param  array    $values 需要替换的参数
 * @param  string   $lang   指定的语言类型
 * @return string
 */
function __($string, array $values = null, $lang = null)
{
    return service('i18n')->translate($string, $values, $lang);
}

/**
 * 确保一个可迭代的数据类型, 可用于foreach，避免判断
 * 如果　$iterator　是一个可迭代类型则返回其本身，否则返回一个空数组
 *
 * @param  mixed   $iterator
 * @return mixed
 */
function _i($iterator)
{
    return is_array($iterator) || is_object($iterator)
        ? $iterator
        : [];
}

/**
 * 简化三元表达式
 *
 * @param  $boolean $bool
 * @param  mixed    $onTrue
 * @param  mixed    $onFalse
 * @return mixed
 */
function on($bool, $onTrue, $onFalse = null)
{
    return $bool ? $onTrue : $onFalse;
}

/**
 * 返回格式化的 json 数据
 *
 * @param  array    $array
 * @param  boolean  $pretty    美化 json 数据
 * @param  boolean  $unescaped 关闭 Unicode 编码
 * @return string
 */
function json_it(array $array, $pretty = true, $unescaped = true)
{
    // php 5.4+
    if (defined('JSON_PRETTY_PRINT') && defined('JSON_UNESCAPED_UNICODE')) {
        if ($pretty && $unescaped) {
            $options = JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE;
        } elseif ($pretty) {
            $options = JSON_PRETTY_PRINT;
        } elseif ($unescaped) {
            $options = JSON_UNESCAPED_UNICODE;
        } else {
            $options = null;
        }

        return json_encode($array, $options);
    }

    if ($unescaped) {
        // convmap since 0x80 char codes so it takes all multibyte codes (above ASCII 127).
        // So such characters are being "hidden" from normal json_encoding
        $tmp = [];
        array_walk_recursive($array, function (&$item, $key) {
            if (is_string($item)) {
                $item = mb_encode_numericentity($item, [0x80, 0xffff, 0, 0xffff], 'UTF-8');
            }
        });
        $json = mb_decode_numericentity(json_encode($array), [0x80, 0xffff, 0, 0xffff], 'UTF-8');
    } else {
        $json = json_encode($array);
    }

    if ($pretty) {
        $result = '';
        $pos = 0;
        $strLen = strlen($json);
        $indentStr = "\t";
        $newLine = "\n";
        $prevChar = '';
        $outOfQuotes = true;

        for ($i = 0; $i <= $strLen; $i++) {
            // Grab the next character in the string.
            $char = substr($json, $i, 1);

            // Are we inside a quoted string
            if ('"' == $char && '\\' != $prevChar) {
                $outOfQuotes = !$outOfQuotes;

                // If this character is the end of an element,
                // output a new line and indent the next line.
            } elseif (('}' == $char || ']' == $char) && $outOfQuotes) {
                $result .= $newLine;
                $pos--;
                for ($j = 0; $j < $pos; $j++) {
                    $result .= $indentStr;
                }
            }

            // Add the character to the result string.
            $result .= $char;

            // If the last character was the beginning of an element,
            // output a new line and indent the next line.
            if ((',' == $char || '{' == $char || '[' == $char) && $outOfQuotes) {
                $result .= $newLine;
                if ('{' == $char || '[' == $char) {
                    $pos++;
                }

                for ($j = 0; $j < $pos; $j++) {
                    $result .= $indentStr;
                }
            }

            $prevChar = $char;
        }

        $json = $result;
    }

    return $json;
}

/**
 * 隐藏当前系统路径
 *
 *     maskroot('/web/myapp/app/config/db.php') // ~/app/config/db.php
 *
 * @param  string   $path
 * @return string
 */
function maskroot($path)
{
    return str_replace(ROOT_PATH, '~', $path);
}

/**
 * 执行 curl 请求，并返回响应内容
 *
 * @param  string   $url
 * @param  array    $data
 * @param  array    $options
 * @return string
 */
function curl($url, array $data = null, array $options = null)
{
    $ch = curl_init();

    curl_setopt_array($ch, [
        CURLOPT_TIMEOUT => 30,
        CURLOPT_URL => $url,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_RETURNTRANSFER => 1,
    ]);

    if ($data) {
        $data = http_build_query($data);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-type: application/x-www-form-urlencoded',
            'Content-Length: ' . strlen($data),
        ]);
    }

    if ($options) {
        curl_setopt_array($ch, $options);
    }

    $response = curl_exec($ch);
    curl_close($ch);

    return $response;
}

/**
 * 写入缓存
 *
 * @link   http://docs.phalconphp.com/zh/latest/reference/cache.html
 *
 * @param string  $key
 * @param mixed   $data
 * @param integer $lifetime
 * @param boolean $stopBuffer
 */
function cache_save($key, $data, $lifetime = 86400, $stopBuffer = false)
{
    return service('cache')->save($key . '.cache', $data, $lifetime, $stopBuffer);
}

/**
 * 获取缓存
 *
 * @link   http://docs.phalconphp.com/zh/latest/reference/cache.html
 *
 * @param  string  $key
 * @param  mixed   $default
 * @return mixed
 */
function cache_get($key, $default = null)
{
    $cache = service('cache')->get($key . '.cache');

    return null === $cache ? $default : $cache;
}

/**
 * 删除缓存
 *
 * @link   http://docs.phalconphp.com/zh/latest/reference/cache.html
 *
 * @param  string    $key
 * @return boolean
 */
function cache_del($key)
{
    return service('cache')->delete($key . '.cache');
}

/**
 * 设置 cookie 值
 *
 * @param string  $name
 * @param mixed   $value
 * @param integer $expire
 */
function cookie_set($name, $value, $expire = null)
{
    return service('cookies')->set($name, $value, $expire);
}

/**
 * 获取 cookie 值
 *
 * @param  string  $name
 * @param  mixed   $default
 * @return mixed
 */
function cookie_get($name, $default = null)
{
    $value = service('cookies')->get($name);

    return null === $value ? $default : $value;
}

/**
 * 删除 cookie
 *
 * @param  string    $name
 * @return boolean
 */
function cookie_del($name)
{
    return service('cookies')->delete($name);
}

/**
 * 设置 session 值
 *
 * @link  http://docs.phalconphp.com/zh/latest/reference/session.html
 * @link  http://docs.phalconphp.com/zh/latest/api/Phalcon_Session_AdapterInterface.html
 *
 * @param string $name
 * @param mixed  $value
 */
function session_set($name, $value = null)
{
    if (is_array($name)) {
        foreach ($name as $k => $v) {
            service('session')->set($k, $v);
        }
    } else {
        service('session')->set($name, $value);
    }

    return service('session');
}

/**
 * 获取 session 值
 *
 * @param  string  $name
 * @param  mixed   $default
 * @return mixed
 */
function session_get($name, $default = null)
{
    return service('session')->get($name, $default);
}

/**
 * 删除 session
 *
 * @param  string    $name
 * @return boolean
 */
function session_del($name)
{
    return service('session')->remove($name);
}

if (!function_exists('http_build_url')) {
    define('HTTP_URL_REPLACE', 1);          // Replace every part of the first URL when there's one of the second URL
    define('HTTP_URL_JOIN_PATH', 2);        // Join relative paths
    define('HTTP_URL_JOIN_QUERY', 4);       // Join query strings
    define('HTTP_URL_STRIP_USER', 8);       // Strip any user authentication information
    define('HTTP_URL_STRIP_PASS', 16);      // Strip any password authentication information
    define('HTTP_URL_STRIP_AUTH', 32);      // Strip any authentication information
    define('HTTP_URL_STRIP_PORT', 64);      // Strip explicit port numbers
    define('HTTP_URL_STRIP_PATH', 128);     // Strip complete path
    define('HTTP_URL_STRIP_QUERY', 256);    // Strip query string
    define('HTTP_URL_STRIP_FRAGMENT', 512); // Strip any fragments (#identifier)
    define('HTTP_URL_STRIP_ALL', 1024);     // Strip anything but scheme and host

    /**
     * Build an URL
     * The parts of the second URL will be merged into the first according to the flags argument.
     *
     * @param mixed   (Part(s) of) an URL in form of a string or associative array like parse_url() returns
     * @param mixed   Same     as the first argument
     * @param integer A        bitmask of binary or'ed HTTP_URL constants (Optional)HTTP_URL_REPLACE is the default
     * @param array   If       set, it will be filled with the parts of the composed url like parse_url() would return
     */
    function http_build_url($url, $parts = [], $flags = HTTP_URL_REPLACE, &$new_url = false)
    {
        $keys = ['user', 'pass', 'port', 'path', 'query', 'fragment'];

        // HTTP_URL_STRIP_ALL becomes all the HTTP_URL_STRIP_Xs
        if ($flags & HTTP_URL_STRIP_ALL) {
            $flags |= HTTP_URL_STRIP_USER;
            $flags |= HTTP_URL_STRIP_PASS;
            $flags |= HTTP_URL_STRIP_PORT;
            $flags |= HTTP_URL_STRIP_PATH;
            $flags |= HTTP_URL_STRIP_QUERY;
            $flags |= HTTP_URL_STRIP_FRAGMENT;
        }
        // HTTP_URL_STRIP_AUTH becomes HTTP_URL_STRIP_USER and HTTP_URL_STRIP_PASS
        elseif ($flags & HTTP_URL_STRIP_AUTH) {
            $flags |= HTTP_URL_STRIP_USER;
            $flags |= HTTP_URL_STRIP_PASS;
        }

        // Parse the original URL
        $parse_url = parse_url($url);

        // Scheme and Host are always replaced
        if (isset($parts['scheme'])) {
            $parse_url['scheme'] = $parts['scheme'];
        }

        if (isset($parts['host'])) {
            $parse_url['host'] = $parts['host'];
        }

        // (If applicable) Replace the original URL with it's new parts
        if ($flags & HTTP_URL_REPLACE) {
            foreach ($keys as $key) {
                if (isset($parts[$key])) {
                    $parse_url[$key] = $parts[$key];
                }
            }
        } else {
            // Join the original URL path with the new path
            if (isset($parts['path']) && ($flags & HTTP_URL_JOIN_PATH)) {
                if (isset($parse_url['path'])) {
                    $parse_url['path'] = rtrim(str_replace(basename($parse_url['path']), '', $parse_url['path']), '/') . '/' . ltrim($parts['path'], '/');
                } else {
                    $parse_url['path'] = $parts['path'];
                }
            }

            // Join the original query string with the new query string
            if (isset($parts['query']) && ($flags & HTTP_URL_JOIN_QUERY)) {
                if (isset($parse_url['query'])) {
                    $parse_url['query'] .= '&' . $parts['query'];
                } else {
                    $parse_url['query'] = $parts['query'];
                }
            }
        }

        // Strips all the applicable sections of the URL
        // Note: Scheme and Host are never stripped
        foreach ($keys as $key) {
            if ($flags & (int) constant('HTTP_URL_STRIP_' . strtoupper($key))) {
                unset($parse_url[$key]);
            }
        }

        $new_url = $parse_url;

        return
            ((isset($parse_url['scheme'])) ? $parse_url['scheme'] . '://' : '') .
            ((isset($parse_url['user'])) ? $parse_url['user'] . ((isset($parse_url['pass'])) ? ':' . $parse_url['pass'] : '') . '@' : '') .
            ((isset($parse_url['host'])) ? $parse_url['host'] : '') .
            ((isset($parse_url['port'])) ? ':' . $parse_url['port'] : '') .
            ((isset($parse_url['path'])) ? $parse_url['path'] : '') .
            ((isset($parse_url['query'])) ? '?' . $parse_url['query'] : '') .
            ((isset($parse_url['fragment'])) ? '#' . $parse_url['fragment'] : '');
    }
}

/**
 * 获取文件上传器
 *
 * @param  array|string       $keys
 * @param  array              $config
 * @return \Formax\Uploader
 */
function get_uploader($keys, array $config = null)
{
    is_array($keys) || $keys = [$keys];
    $uploader = \Formax\Uploader::factory($config);
    foreach (service('request')->getUploadedFiles() as $file) {
        if (in_array($file->getKey(), $keys)) {
            $uploader->save($file);
        }
    }

    return $uploader;
}

/**
 * 获取最后执行的 sql 语句
 *
 * @return string
 */
function last_sql()
{
    return service('dbListener')->getProfiler()->getLastProfile()->getSQLStatement();
}

/**
 * 判断两个浮点数是否相等
 * @param  float  $num1
 * @param  float  $num2
 * @param  float  $diff
 * @return bool
 */
function float_eq($num1, $num2, $diff = 0.000001)
{
    return abs($num1 - $num2) < $diff;
}

/**
 * 替换 文件扩展
 */
function replace_storage_extension($url)
{
    if (strpos($url, 'storage/') === false) {
        return $url;
    }

    return rev_extension($url);
}

/**
 * 反转扩展名
 */
function rev_extension($url)
{
    $url = preg_replace_callback('/\.([a-zA-Z]+)/', function ($match) {
        return '.' . strrev($match[1]);
    }, $url);

    return $url;
}

function logger($message, $filename='log')
{
    $log_dir = ROOT_PATH . '/tmp/logs/';
    if ( !is_dir($log_dir) ) {
        mkdir($log_dir, 0777);
    }
    $log_file = $log_dir . $filename . '-' . date('Ymd') . '.log';

    if ( is_string($message) ) {
        $message = "[" . date('Y-m-d H:i:s') . "]\n" . $message . "\n";
    } else {
        $message = "[" . date('Y-m-d H:i:s') . "]\n" . var_export($message, true) . "\n";
    }

    return file_put_contents($log_file, $message, FILE_APPEND);
}
