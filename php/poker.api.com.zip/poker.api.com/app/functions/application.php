<?php

/**
 * 项目相关函数
 */
/**
 * 生成并输出验证码
 *
 * @param  string       $phrase
 * @param  integer      $width
 * @param  integer      $height
 * @throws \Exception
 */
function captcha_output($phrase = null, $width = null, $height = null)
{
    if (!class_exists('\Gregwar\Captcha\CaptchaBuilder')) {
        throw new \Exception('Require components: Gregwar\Captcha (ref: https://github.com/Gregwar/Captcha)');
    }

    S('response')->setContentType('image/jpeg');

    $builder = new \Gregwar\Captcha\CaptchaBuilder($phrase);

    // 输出验证码
    $builder
        ->setMaxAngle(5)                                                              // 最大倾斜角度
        ->setMaxOffset(2)                                                             // 最大偏移距离
        ->setTextColor(mt_rand(0, 120), mt_rand(0, 120), mt_rand(0, 120))             // 文本颜色
        ->setBackgroundColor(mt_rand(220, 255), mt_rand(220, 255), mt_rand(180, 255)) // 背景颜色
        ->setMaxFrontLines(0)                                                         // 最大前景干扰线数量
        ->setMaxBehindLines(5)                                                        // 最大背景干扰线数量
        ->build($width, $height)
        ->output();

    // 存储到 session 中
    S('session')->set('captcha_phrase', strtolower($builder->getPhrase()));
}

/**
 * 校验验证码的正确性
 *
 * @param  string    $phrase
 * @return boolean
 */
function captcha_validate($phrase)
{
    return strtolower($phrase) === S('session')->get('captcha_phrase', false);
}

/**
 * 销毁验证码
 *
 * @param  string    $phrase
 * @return boolean
 */
function captcha_destroy()
{
    S('session')->remove('captcha_phrase');
}

/**
 * 获取 js 目录名
 *
 * @return string
 */
function js_dir()
{
    return DEVELOPMENT || TESTING ? 'js_src' : 'js';
}

/**
 * 获取 JS 网址
 *
 * @param  string   $jsfile
 * @param  boolean  $jsfile
 * @return string
 */
function js_url($jsfile = null, $time = true)
{
    $jsfile = ltrim($jsfile, '/');

    if (empty($jsfile)) {
        $time = false;
    }

    return static_url(js_dir() . '/' . $jsfile, $time);
}

/**
 * 加载 RequireJS
 *
 * @param  string   $name
 * @return string
 */
function require_js($name)
{
    $baseUrl = js_url();
    $urlArgs = DEVELOPMENT ? time() : app_update_time();
    $bootup = js_url('require/bootup.js');

    return <<<RJS
<script type="text/javascript" src="{$bootup}"></script>
<script type="text/javascript">
new BootUp([
    '{$baseUrl}require/require.js',
    '{$baseUrl}config.js',
    '{$baseUrl}{$name}.js'
], {
    version: '{$urlArgs}',
    success: function () {
        require({
            baseUrl: '{$baseUrl}',
            urlArgs: '{$urlArgs}'
        });
    }
});
</script>
RJS;
}

/**
 * 发送邮件
 *
 * @param  string|array $to
 * @param  string       $subject
 * @param  string       $body
 * @param  arrray       $params
 * @param  string       $contentType
 * @throws \Exception
 * @return integer
 */
function send_mail($to, $subject, $body, array $params = null, $contentType = 'text/html')
{
    if (!class_exists('\Swift_Mailer')) {
        throw new \Exception('Require components: Swift_Mailer (ref: http://swiftmailer.org/)');
    }

    if (empty($to) ||
        (is_string($to) && !is_email($to)) ||
        empty($subject) ||
        empty($body)
    ) {
        return false;
    }

    $config = C('mail.smtp');

    // 创建 transport
    $transport = \Swift_SmtpTransport::newInstance($config->host, $config->port);

    // Set the auth
    if (isset($params['auth'])) {
        $transport->setUsername($params['auth']['username'])
            ->setPassword($params['auth']['password']);
    } else {
        $transport->setUsername($config->username)
            ->setPassword($config->password);
    }

    // 创建邮件消息
    $message = \Swift_Message::newInstance($subject, $body, $contentType);

    // 发件人
    if (isset($params['from'])) {
        $message->setFrom($params['from']);
    } else {
        $message->setFrom($config->from->mail, $config->from->name);
    }

    // 收件人
    if (isset($params['to'])) {
        $message->setTo($params['to']);
    } else {
        $message->setTo($to);
    }

    // 抄送
    if (isset($params['cc'])) {
        $message->setCc($params['cc']);
    }

    // 暗送
    if (isset($params['bcc'])) {
        $message->setBcc($params['bcc']);
    }

    // 回复
    if (isset($params['reply-to'])) {
        $message->setReplyTo($params['reply-to']);
    }

    // 添加附件
    if (isset($params['files'])) {
        $files = is_array($params['files']) ? $params['files'] : [$params['files']];
        foreach ($files as $file) {
            if (is_file($file)) {
                $message->attach(\Swift_Attachment::fromPath($file));
            }
        }
    }

    // 发送邮件
    return \Swift_Mailer::newInstance($transport)->send($message);
}

/**
 * 生成 gravatar 头像地址
 *
 * @link   http://cn.gravatar.com/
 *
 * @param  string   $email
 * @param  integer  $width
 * @return string
 */
function gravatar_url($email, $width = 30)
{
    return 'http://s.gravatar.com/avatar/' . md5(strtolower($email)) . "?s={$width}";
}

/**
 * 调用 CRM\Translates::read 读取翻译结果
 *
 * @param  string   $default
 * @param  string   $keyword
 * @param  integer  $foreign_id
 * @param  string   $lang
 * @return string
 */
function db_translate($default, $keyword, $foreign_id, $lang = null)
{
    if (null === $lang) {
        $lang = S('i18n')->getDefault();
    }

    if ('en-us' !== $lang && $string = CRM\Translates::read($keyword, $foreign_id, $lang)) {
        return $string;
    }

    return $default;
}

/**
 * 进度条颜色
 *
 * @param  float    $percent
 * @return string
 */
function progress_color($percent)
{
    switch (true) {
        case $percent >= 100:
            return 'success';
        case $percent > 75:
            return 'primary';
        case $percent > 50:
            return 'info';
        case $percent > 25:
            return 'warning';
        default:
            return 'danger';
    }
}

/**
 * 赠金名称
 *
 * @param  string   $io_type
 * @return string
 */
function bonus_name($io_type)
{
    S('i18n')->import('bonus');

    switch ($io_type) {
        case 'awd_trade':
            return __('Bonus from Trade');
        case 'bonus_contest':
            return __('Bonus from Contest');
        case 'bonus_deposit':
            return __('Bonus from Deposit');
        case 'bonus_direct':
            return __('Bonus');
        case 'bonus_openreal':
            return __('welcome bonus');
        case 'bonus_test':
            return __('Bonus from Test');
        case 'bonus_invite1':
            return __('Invite Friend Bonus');
        case 'bonus_invite2':
            return __('Invite Friend Bonus');
        case 'bonus_credit':
        case 'bonus_credit2':
        case 'bonus_credit3':
            return __('Credit Bonus');
        case 'bonus_guess':
            return __('Guess Bonus');
        case 'bonus_exchange':
            return __('Exchange Bonus');
        case 'bonus_special':
        default:
            return __('Speical Bonus');
    }
}

/**
 * 输出一个csv头，用于下载
 *
 * @param  string $filename, 输出的下载文件名
 * @return null
 */
function csv_header_4_downloading($filename)
{
    header('Content-Encoding: gbk');
    header('Content-type: text/csv; charset=gbk');
    header("Content-Disposition: attachment; filename={$filename}.csv");

    return null;
}

// 打印单行 csv
function csv_line($data)
{
    if (func_num_args() > 1) {
        $data = func_get_args();
    }

    foreach ($data as $k => &$v) {
        if (strpos($v, ',') !== false ||
            strpos($v, '"') !== false ||
            strpos($v, "\n") !== false) {
            $v = '"' . str_replace('"', '""', $v) . '"';
        }
    }

    return to_gbk(implode(',', $data)) . "\n";
}

// 生成二维码
function qrcode_generated($text, $outfile = false)
{
    $qrCode = new \Endroid\QrCode\QrCode();

    $dir = dirname($outfile);
    if (!is_dir($dir)) {
        @mkdir($dir, 0777, true);
        @chmod($dir, 0777);
    }

    $qrCode
        ->setText($text)
        ->setSize(185)
        ->setPadding(10)
        ->setErrorCorrection('LOW')
        ->setForegroundColor(['r' => 0, 'g' => 0, 'b' => 0, 'a' => 0])
        ->setBackgroundColor(['r' => 255, 'g' => 255, 'b' => 255, 'a' => 0]);
    if ($outfile) {
        return $qrCode->save($outfile);
    }

    return $qrCode;
}

// 查询手机号码归属地
function query_mobile_location($mobile)
{
    static $last_time = 0;

    if (!preg_match('/^\d{11}$/', $mobile)) {
        return false;
    }

    $url = 'http://www.ip138.com/search.asp?action=mobile&mobile=' . $mobile;

    try {
        // file_get_contents 会抛出一个异常
        if (!$content = @file_get_contents($url)) {
            return false;
        }
    } catch (Exception $e) {
        return false;
    }

    $last_time = time();

    // 转码
    $content = mb_convert_encoding($content, 'UTF-8', 'GB2312');

    // 过滤注释和空白字符
    $content = preg_replace('/<\!--.*?-->/si', '', $content);
    $content = preg_replace('/\s+/', ' ', $content);

    // 缩小范围
    if (!$pos = strpos($content, '卡号归属地')) {
        return false;
    }

    $content = substr($content, strpos($content, '卡号归属地') + 20, 100);

    // 匹配查询结果
    if (!$city = preg_replace('/[^<]*<td [^>]+>([^<]+)<.*/i', '$1', $content)) {
        return false;
    }

    if (strpos($city, '&nbsp;') === false) {
        return false;
    }

    list($p, $c) = explode('&nbsp;', $city);

    return ['province' => $p, 'city' => '' === $c ? $p : $c];
}

/**
 * 将数据库查询字段进行通用加工
 * @param  array $conditions          条件数组
 * @param  array $bind                绑定数组
 * @return array 条件和绑定值
 */
function format_query_conditions($conditions = [], $bindParams = [])
{

    // 获取有交集的conditions项
    if (!$conditions = array_intersect_key($conditions, $bindParams)) {
        return [];
    }

    $bind = [];
    foreach ($conditions as $key => $cond) {
        $bind_value = trim($bindParams[$key]);
        // 处理like字段
        if (strpos($cond, 'LIKE')) {
            $bind[$key] = '%' . $bind_value . '%';
        }
        // 时间开始范围 字段名以 _to 结尾
        elseif (substr($key, -3) === '_to') {
            $bind[$key] = strtotime($bind_value . ' 23:59:59');
        }
        // 时间开始范围 字段名以 _from 结尾
        elseif (substr($key, -5) === '_from') {
            $bind[$key] = strtotime($bind_value . ' 00:00:00');
        }
        // 默认值
        else {
            $bind[$key] = $bind_value;
        }
    }

    return $bind ? ['conditions' => $conditions, 'bind' => $bind] : [];
}

/**
 * 敏感数据加密后，表单查询手机时，兼容'86 xxxxxx'这种情况
 * @param $phone
 * @param $isEncrypt true时，$phone参数为加密串; false时，$phone为非加密串
 */
function format_query_phone($phone, $isEncrypt = true)
{
    if (empty($phone)) {
        return false;
    }

    if ($isEncrypt) {
        $phone = S('security')->decrypt($phone);
        if (!$phone) {
            return false;
        }
    }

    $phone_list = [];
    array_push($phone_list, $phone);
    if (substr($phone, 0, 2) != '86') {
        array_push($phone_list, '86 ' . $phone);
    } else {
        array_push($phone_list, substr($phone, 3));
    }

    return S('security')->batchEncrypt($phone_list);
}

/**
 * 表单数据加密
 */
function form_encrypt($result, $name = '', $security_field_list = ['email', 'phone'])
{
    if (empty($result)) {
        return $result;
    }

    if (is_array($result)) {
        foreach ($result as $key => &$val) {
            $val = form_encrypt($val, $key, $security_field_list);
        }
    } else {
        if (in_array($name, $security_field_list, true)) {
            //手机号区号处理
            $result = trim($result);
            if (preg_match('/^(1\d{10})$/', $result)) {
                $result = '86 ' . $result;
            }
            $encrypt = S('security')->encrypt($result);
            $result = $encrypt ? $encrypt : $result;
        }
    }

    return $result;
}

/**
 * 表单数据解密
 */
function form_decrypt($filter)
{
    $security_field_list = ['email', 'phone'];
    if (!is_array($filter)) {
        return $filter;
    }
    foreach ($filter as $key => $val) {
        if (!empty($val) && in_array($key, $security_field_list) && is_base64_str($val)) {
            $decrypt = S('security')->decrypt($val);
            $filter[$key] = $decrypt ? $decrypt : $val;
        }
        if ($key == 'phone' && (substr($filter[$key], 0, 3) == '86 ')) {
            $filter[$key] = substr($filter[$key], 3);
        }
    }

    return $filter;
}

// 导出
function exportCSV($base = [], $info = [])
{
    csv_header_4_downloading($base['filename']);
    echo csv_line($base['rows']);
    if (empty($info)) {
        exit;
    }
    foreach ($info as $item) {
        echo csv_line($item);
    }
}

/**
 * 查询文档可参考
 * https://www.elastic.co/guide/en/elasticsearch/reference/current/query-filter-context.html
 *     [
 *         ['match'  => ['uid'=>'111111']]
 *     ]
 *                     ['term'=>['batch_id'=>111]],
 *                     ['range'=>['field'=>['gt'=>0]]]
 *                 ]
 * @param  [type]  $index           []
 * @param  [type]  $must
 * @param  array   $filter          [
 * @param  array   $sort            [['field'=>['order'=>'desc']]]
 * @param  integer $page            [description]
 * @param  integer $limit           [description]
 * @return [type]  [description]
 */
function esQuery($index, $must, $filter = [], $sort = [], $page = 1, $limit = 10)
{
    $cfg = config("es.{$index}");
    $param = [
        'index' => $cfg->index,
        'type' => $cfg->type,
        'body' => [
            'sort' => $sort,
            'query' => [
                'bool' => [
                    'must' => $must,
                    'filter' => $filter,
                ],
            ],
        ],
    ];

    $res = service('esclient')->count($param);
    $record_count = isset($res['count']) ? $res['count'] : 0;

    $current_record = ($page - 1) * $limit;
    if ($current_record < 0) {
        $current_record = 0;
    }
    if ($current_record >= $record_count) {
        $current_record = $record_count;
    }

    $page_count = ceil($record_count / $limit);

    if ($page >= $page_count) {
        $page = $page_count;
    }
    $param['body']['from'] = $current_record;
    $param['body']['size'] = $limit;
    try {
        $res = service('esclient')->search($param);
        $hits = isset($res['hits']['hits']) ? $res['hits']['hits'] : [];
    } catch (Exception $e) {
        $hits = [];
    }

    $item_list = [];
    foreach ($hits as $val) {
        $item_list[] = json_decode(json_encode($val['_source']));
    }

    $paginate = new \stdClass;
    $paginate->items = $item_list;
    $paginate->first = 1;
    $paginate->before = ($page >= 1) ? $page - 1 : 1;
    $paginate->current = ($page == 0) ? 1 : $page;
    $paginate->last = $page_count;
    $paginate->next = ($page < $page_count) ? $page + 1 : $page_count;
    $paginate->total_pages = $page_count;
    $paginate->total_items = $record_count;
    $paginate->limit = $limit;

    return $paginate;
}
