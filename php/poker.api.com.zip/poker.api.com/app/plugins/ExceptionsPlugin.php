<?php

use Phalcon\Events\Event;
use Phalcon\Mvc\Dispatcher;
use Phalcon\Mvc\Dispatcher\Exception as DispatcherException;

/**
 * 异常处理
 */
class ExceptionsPlugin extends Phalcon\Mvc\User\Plugin
{
    public function beforeException(Event $event, Dispatcher $dispatcher, $exception)
    {
        $dispatcher->setParam('exception', $exception);

        $message = sprintf('%s [%d]: %s (in %s on line %d)',
            get_class($exception),
            $exception->getCode(),
            maskroot($exception->getMessage()),
            maskroot($exception->getFile()),
            $exception->getLine());

        if (!$exception instanceof DispatcherException) {
            logger($message);
        }

        // CLI 输出
        if (IS_CLI) {
            logger($message);

            return false;
        }

        $dispatcher->forward([
            'controller' => 'error',
            'action'     => 'index',
        ]);

        return false;
    }
}
