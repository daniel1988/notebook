<?php

use Phalcon\Db\Profiler;

/**
 * 数据库事件监听器
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/events.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Db_Profiler.html
 */
class DbListenerPlugin extends Phalcon\Mvc\User\Plugin
{
    protected $_profiler;

    /**
     * Creates the profiler and starts the logging
     */
    public function __construct()
    {
        $this->_profiler = new Profiler();
    }

    /**
     * This is executed if the event triggered is 'beforeQuery'
     */
    public function beforeQuery($event, $connection)
    {
        $this->_profiler->startProfile($connection->getSQLStatement());
    }

    /**
     * This is executed if the event triggered is 'afterQuery'
     */
    public function afterQuery($event, $connection)
    {
        $this->_profiler->stopProfile();

        $profile = $this->_profiler->getLastProfile();
        $secs    = round($profile->getTotalElapsedSeconds(), 6);

        // 不同的时间消耗，定义不同的日志级别
        if ($secs >= 10) {
            $level = Formax\Logger::ERROR;
        } elseif ($secs >= 5) {
            $level = Formax\Logger::WARNING;
        } elseif ($secs >= 1) {
            $level = Formax\Logger::INFO;
        } else {
            $level = Formax\Logger::DEBUG;
        }

        $this->logger['database']->log($level, "[$secs] " . $profile->getSQLStatement());
    }

    public function getProfiler()
    {
        return $this->_profiler;
    }
}
