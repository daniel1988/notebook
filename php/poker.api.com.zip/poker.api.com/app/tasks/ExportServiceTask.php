<?php

use Formax\CLI\Task;
use Formax\Logger;

class ExportServiceTask extends Task
{
    public $serv        = null;
    public $listen      = '127.0.0.1';
    public $port        = 10110;
    public $processName = 'crm-export-service';
    public $logger      = null;
    public $pid         = null;

    // @link http://wiki.swoole.com/wiki/page/274.html
    public $config = [
        'worker_num'    => 1,           // 启动的worker进程数
        'max_request'   => 1024,        // worker进程的最大任务数
        'max_conn'      => 256,         // 服务器程序，最大允许的连接数
        'daemonize'     => DEVELOPMENT, // 守护进程化
        'dispatch_mode' => 2,
        'chroot'        => ROOT_PATH, // 重定向Worker进程的文件系统根目录
    ];

    public function registerOptions()
    {
        $this->registerOption('listen', 'l', false, true, '主机监听地址，默认为 127.0.0.1')
            ->registerOption('port', 'p', false, true, '主机监听端口，默认为 8769')
            ->registerOption('process-name', 'n', false, true, '进程名称，默认为 CrmExportService');
    }

    public function mainAction()
    {
        $this->logger = S('logger')->get('cli');

        foreach ($this->args as $property => $value) {
            if (property_exists($this, $property)) {
                $this->$property = $value;
            }
        }

        $this->runSwooleServer();
    }

    public function runSwooleServer()
    {

        $this->serv = new swoole_server($this->listen, $this->port);

        // 设置进程名称
        $processName = $this->processName;
        if (function_exists('cli_set_process_title')) {
            cli_set_process_title($processName);
        } else {
            swoole_set_process_name($processName);
        }

        // 自动绑定事件处理方法
        // @link http://wiki.swoole.com/wiki/page/41.html
        foreach (get_class_methods($this) as $method) {
            if (substr($method, 0, 2) === 'on') {
                // $this->logger->debug(substr($method, 0, 2) . '' . substr($method, 2));
                $this->serv->on(substr($method, 2), [$this, $method]);
            }
        }

        // 启动服务
        $this->serv->start();
    }

    public function onStart($serv)
    {
        $this->logger->info(str_repeat('=', 80));
        $this->logger->info('CRM 文件导出服务启动成功！');
        $this->logger->info(str_repeat('=', 80));

        // $this->log(
        //     "- SWOOLE 版本： %s\n" .
        //     "- 进程名称: %s\n" .
        //     "- MASTER PID: %d\n" .
        //     "- MANAGER PID: %d\n" .
        //     "- 监听地址: %s:%d\n",
        //     SWOOLE_VERSION,
        //     $this->processName,
        //     $serv->master_pid,
        //     $serv->manager_pid,
        //     $this->listen,
        //     $this->port
        // );
    }

    public function onShutdown($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onWorkerStart($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onWorkerStop($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onTimer($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onConnect($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onReceive($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onPacket($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onClose($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onTask($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onFinish($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onPipeMessage($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onWorkerError($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onManagerStart($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }

    public function onManagerStop($serv)
    {
        $this->logger->debug(__FUNCTION__ . '->');
    }
}
