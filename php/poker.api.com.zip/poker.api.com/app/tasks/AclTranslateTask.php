<?php
/**
 * 根据配置文件 ~/app/config/acl.php 生成对应的语言包文件
 * @cli-usage acl-translate -g -l zh-cn
 */
class AclTranslateTask extends \Formax\CLI\Task
{

    public function registerOptions()
    {
        $this
            ->registerOption('gen', 'g', false, false, '生成语言包文件')
            ->registerOption('lang', 'l', false, true, '指定语言');
    }

    public function mainAction()
    {
        if ($this->args->isEmpty()) {
            return $this->displayHelp();
        }

        if ($this->args->get('gen')) {
            $this->generateLang();
        }
    }

    public function generateLang()
    {
        $data = [];

        foreach (C('acl') as $group => $items) {
            foreach ($items as $key => $value) {
                if (is_object($value)) {
                    $data[$group][$key] = $key;
                    foreach ($value as $k => $v) {
                        $data[$group]["$key.$k"] = $k;
                        foreach ($v as $a) {
                            $data['action'][$a] = $a;
                        }
                    }
                } else {
                    $data[$group][$value] = $value;
                }
            }
        }

        if ($lang = $this->args->get('lang')) {
            $this->_writeLangFile($data, $lang);
        } else {
            foreach (C('application.i18n.supports') as $lang => $text) {
                $this->_writeLangFile($data, $lang);
            }
        }
    }

    protected function _writeLangFile(array $data, $lang)
    {
        S('i18n')->import('acl');

        $translates = [];
        foreach ($data as $group => $item) {
            $translates[$group] = '---------';
            foreach ($item as $key => $val) {
                $name = "acl.$group.$key";
                $str  = __($name, null, $lang);
                if ($str === $name) {
                    $val = str_replace(['_', '-', '.'], ' ', $val);
                    $str = implode(' ', array_map('ucfirst', explode(' ', $val)));
                }

                $translates[$name] = $str;
            }
        }

        $content = preg_replace('~\n  ~', "\n    ", var_export($translates, true));
        $content = str_replace('array (', '<?php /* ' . date('Y-m-d H:i:s [O]') . "*/\n\nreturn array(", $content) . ';';
        $content = preg_replace_callback("~(\s+)'(\w+)' => '\-+',~", function ($m) {
            return strtoupper("\n{$m[1]}// ------------ {$m[2]} ------------");
        }, $content);

        $file = C('application.i18n.directory') . "/$lang/acl.php";

        $dir = dirname($file);

        if (!is_dir($dir) && mkdir($dir, 0777)) {
            return cli_output('创建目录失败: ' . $dir, 'error');
        }

        if (file_put_contents($file, $content)) {
            return cli_output("ACL 语言包：'$file' 写入成功", 'success');
        }

        return cli_output("ACL 语言包：'$file' 写入失败", 'error');
    }
}
