<?php
// WEB 所在目录
define('DOC_PATH', ROOT_PATH . '/public');

// 项目所在目录
define('APP_PATH', ROOT_PATH . '/app');

// 外部库所在目录
define('VEN_PATH', ROOT_PATH . '/vendor');

// 数据存放目录
define('DATA_PATH', ROOT_PATH . '/data');

// -----------------------------------------------------------------------------
// 项目常量定义
// -----------------------------------------------------------------------------

// 定义项目开始时间
defined('START_TIME') || define('START_TIME', microtime(true));

// 定义项目初始内存
defined('START_MEMORY') || define('START_MEMORY', memory_get_usage());

// 项目版本
define('VERSION', '1.0.0');

// 生产环境
defined('PRODUCTION') || define('PRODUCTION', is_file('/etc/php.env.production'));

// 预发环境
defined('STAGING') || define('STAGING', is_file('/etc/php.env.staging'));

// 测试环境
defined('TESTING') || define('TESTING', is_file('/etc/php.env.testing'));

// 开发环境
defined('DEVELOPMENT') || define('DEVELOPMENT', !(PRODUCTION || STAGING || TESTING));

// -----------------------------------------------------------------------------
// 环境常量定义
// -----------------------------------------------------------------------------

//版本
defined('APP_VERSION') || define(
    'APP_VERSION',
    isset($_SERVER['APP_VERSION']) && 'version' != $_SERVER['APP_VERSION'] ? $_SERVER['APP_VERSION'] : ''
);
unset($_SERVER['APP_VERSION']);

// 定义是否 CLI 模式
define('IS_CLI', (PHP_SAPI === 'cli'));

// 定义是否 windows 环境
define('IS_WIN', (DIRECTORY_SEPARATOR === '\\'));

if (IS_CLI) {
    define('IS_AJAX', false);
    define('IS_CURL', false);
    define('HTTP_HOST', null);
    define('HTTP_PROTOCOL', null);
    define('HTTP_BASE', null);
    define('HTTP_URL', null);
} else {
    // 定义是否 AJAX 请求
    define('IS_AJAX', isset($_SERVER['HTTP_X_REQUESTED_WITH']) &&
        'xmlhttprequest' == strtolower($_SERVER['HTTP_X_REQUESTED_WITH']));

    // 定义是否 cURL 请求
    define('IS_CURL', isset($_SERVER['HTTP_USER_AGENT']) &&
        stripos($_SERVER['HTTP_USER_AGENT'], 'curl') !== false);

    // 定义主机地址
    if (isset($_SERVER['HTTP_HOST'])) {
        define('HTTP_HOST', strtolower($_SERVER['HTTP_HOST']));
    } elseif (isset($_SERVER['HTTP_X_FORWARDED_HOST'])) {
        define('HTTP_HOST', strtolower($_SERVER['HTTP_X_FORWARDED_HOST']));
    }

    // 定义 HTTP 协议
    define('HTTP_PROTOCOL', isset($_SERVER['HTTPS']) && 'on' === $_SERVER['HTTPS'] ? 'https' : 'http');

    // 定义是否 SSL
    define('HTTP_SSL', isset($_SERVER['SERVER_PROTOCOL']) &&
        (strpos($_SERVER['SERVER_PROTOCOL'], 'HTTPS') !== false));

    // 定义当前基础域名
    define('HTTP_BASE', HTTP_PROTOCOL . '://' . HTTP_HOST . '/');

    // 定义当前页面 URL 地址
    define('HTTP_URL', rtrim(HTTP_BASE, '/') . $_SERVER['REQUEST_URI']);
}
