<?php

/**
 * Sets the error handler
 */
set_error_handler(function ($code, $error, $file, $line) {
    throw new ErrorException($error, $code, 0, $file, $line);

    return true;
});

/**
 * The FactoryDefault Dependency Injector automatically register the right services providing a full stack framework
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/di.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_DI.html
 */
$di = new Phalcon\DI\FactoryDefault();

/**
 * Include the application routes
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/routing.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Router.html
 */
$di['router'] = function () {
    return config('routes');
};

/**
 * Create an events manager
 */
$di['eventsManager'] = function () {
    return new Phalcon\Events\Manager();
};

/**
 * The URL component is used to generate all kind of urls in the application
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/url.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Url.html
 */
$di['url'] = function () use ($config) {
    $url = new Phalcon\Mvc\Url();
    $url->setBaseUri($config->url->baseUri);
    $url->setStaticBaseUri($config->url->staticBaseUri);

    return $url;
};

/**
 * Setting up the view component
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/views.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_View.html
 */
$di['view'] = function () use ($config, $di) {
    $view = new Phalcon\Mvc\View();
    $view->setViewsDir($config->view->viewsDir);

    $view->registerEngines([
        '.phtml' => 'Phalcon\Mvc\View\Engine\Php',
    ]);

    return $view;
};

/**
 * Create an database listener
 */
$di['dbListener'] = function () {
    return new DbListenerPlugin();
};

/**
 * Database connection is created based in the parameters defined in the configuration file
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/db.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Db_Adapter_Pdo_Mysql.html
 */
foreach ($config->databases as $name => $options) {
    $di[$name] = function () use ($options, $di) {
        // Create an new database connection
        $connection = new Phalcon\Db\Adapter\Pdo\Mysql($options->toArray());

        // Listen all the database events
        $di['eventsManager']->attach('db', $di['dbListener']);

        // Assign the events manager to the connection
        $connection->setEventsManager($di['eventsManager']);

        return $connection;
    };
}

/**
 * If the configuration specify the use of metadata adapter use it or use memory otherwise
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/models.html#models-meta-data
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Model_MetaData.html
 */
$di['modelsMetadata'] = function () use ($config) {
    if (isset($config->models->metadata)) {
        $metaDataConfig = $config->models->metadata;
        $metadataAdapter = 'Phalcon\Mvc\Model\Metadata\\' . ucfirst($metaDataConfig->adapter);

        return new $metadataAdapter($metaDataConfig->options->toArray());
    }

    return new Phalcon\Mvc\Model\Metadata\Memory();
};

/**
 * Register the crypt service
 */
$di['crypt'] = function () use ($config) {
    $crypt = new Phalcon\Crypt();
    $crypt->setCipher('blowfish');
    $crypt->setKey($config->crypt->salt);

    return $crypt;
};

/**
 * Register the Cookies service
 */
$di['cookies'] = function () use ($config) {
    // 以配置参数合并默认参数
    $params = array_merge(session_get_cookie_params(), $config->cookies->toArray());

    session_set_cookie_params(
        $params['lifetime'],
        $params['path'],
        $params['domain'],
        $params['secure'],
        $params['httponly']
    );

    return new Formax\Cookies($config->cookies->toArray());
};

/**
 * Start the session the first time some component request the session service
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/session.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Session.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Session_Adapter_Files.html
 */
$di['session'] = function () use ($config, $di) {
    /**
     * 使用 memcache 管理 session，会导致刷新 cache 后，登录用户退出
     * 因此改为使用 database 管理
     */
    if (isset($config->session)) {
        $sessionConfig = $config->session;
        $sessionAdapter = 'Phalcon\Session\Adapter\\' . ucfirst($sessionConfig->adapter);

        $session = new $sessionAdapter($sessionConfig->options->toArray());
    } else {
        $session = new Phalcon\Session\Adapter\Files;
    }

    $session->start();

    return $session;
};

/**
 * Register the flash service with custom CSS classes
 *
 * @link http://v3.bootcss.com/css/#buttons-options
 * @link http://docs.phalconphp.com/zh/latest/reference/flash.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Flash.html
 */
$di['flash'] = new Phalcon\Flash\Direct([
    'error' => 'alert alert-danger',
    'success' => 'alert alert-success',
    'notice' => 'alert alert-info',
    'warning' => 'alert alert-warning',
]);

/**
 * We register the events manager
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/dispatching.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Dispatcher.html
 */
$di['dispatcher'] = function () use ($di) {
    $dispatcher = new Phalcon\Mvc\Dispatcher();

    // We listen for events in the dispatcher using the exceptions plugin
    $di['eventsManager']->attach('dispatch:beforeException', new ExceptionsPlugin);

    $dispatcher->setEventsManager($di['eventsManager']);

    return $dispatcher;
};

/**
 * Register the default cache component
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/cache.html
 */
$di['cache'] = function () use ($config, $di) {
    // Cache the files for 2 days using a Data frontend
    $frontCache = new Phalcon\Cache\Frontend\Data($config->cache->frontendOptions->toArray());

    // Create the component that will cache "Data"
    $cache = new Phalcon\Cache\Backend\Memcache($frontCache, $config->cache->backendOptions->toArray());

    return $cache;
};

/**
 * 多语言设置
 */
$di['i18n'] = function () use ($di) {
    $config = config('application.i18n');
    $request = $di['request'];
    $cookies = $di['cookies'];

    // 获取语言类型
    if ($request->has($config->key)) {
        $default = $request->get($config->key);
    } elseif ($cookies->has($config->key)) {
        $default = $cookies->get($config->key);
    } else {
        $default = $request->getBestLanguage();
    }

    // 完成 i18n 初始化
    $i18n = new Formax\I18n();
    $i18n->addDirectory($config->directory)
        ->addAliases($config->aliases->toArray())
        ->import($config->import->toArray());

    // 根据别名获取语言类型
    $default = $i18n->getLangByAlias($default);
    $i18n->setDefault(isset($config->supports[$default]) ? $default : $config->default);

    // 存储到 cookie 中
    $cookies->set($config->key, $i18n->getDefault(), time() + 86400 * 30);

    return $i18n;
};

/**
 * 注册 AJAX 处理
 */
$di['ajax'] = function () {
    return new \Formax\AJAX;
};

/**
 * 注册用户权限管理
 */
$di['auth'] = function () {
    $config = config('auth');

    $session = \Formax\Auth\Session::factory(
        $config->driver, $config->options->toArray());

    return new \Formax\Auth\Client($session);
};

/**
 * 加载消息视图助手
 */
$di['helper'] = function () {
    return new \Formax\View\Helper\Message;
};

/**
 * 注册过滤器
 */
$di['filter'] = function () {
    $filter = new \Phalcon\Filter();
    $filter->add('encrypt', function ($result) {
        if (empty($result)) {
            return $result;
        }

        $result = trim($result);
        if (preg_match('/^(1\d{10})$/', $result)) {
            $result = '86 ' . $result;
        }
        $encrypt = S('security')->encrypt($result);
        $result = $encrypt ? $encrypt : $result;

        return $result;
    });

    return $filter;
};
