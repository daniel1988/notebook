<?php
/**
 * 功能: 国内短信发送
 *
 * $sms = new \Sms\Internal();
 * $sms->send('15923297663', 'test');
 */
namespace File;

/**
 * 文件服务client
 */
class StorageClient
{
    private static $domain;
    protected $token;
    protected $appid;
    protected $appkey;

    public function __construct($appid, $appkey)
    {
        $this->appid  = $appid;
        $this->appkey = $appkey;
        self::$domain = C('storage.url');
        $this->setToken();
    }

    //设置token
    public function setToken()
    {
        $data = [
            'app_id'  => $this->appid,
            'app_key' => $this->appkey,
        ];
        try {
            $this->token = $this->curl(self::$domain . '/token', 'POST', $data);
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 上传文件
     */
    public function upload($filePath)
    {
        $data = [
            'token' => $this->token,
        ];
        if (!is_array($filePath)) {
            $filePath = [$filePath];
        }
        foreach ($filePath as $k => $v) {
            $data[$k]          = new \CURLFile($v['filename'], $v['type']);
            $data['md5_' . $k] = md5_file($v['filename']);
        }
        try {
            return $this->curl(self::$domain . '/storage', 'POST', $data);
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 根据所传参数维护一个 指定的file_id
     * 3个参数为 uid_$name, business_type_$name, purpose_$name
     * (all required)
     */
    public function preserve($filePath)
    {
        $data = [
            'token' => $this->token,
        ];
        if (!is_array($filePath)) {
            $filePath = [$filePath];
        }
        foreach ($filePath as $k => $v) {
            $data[$k]                    = new \CURLFile($v['filename'], $v['type']);
            $data['md5_' . $k]           = md5_file($v['filename']);
            $data['uid_' . $k]           = $v['uid'];
            $data['business_type_' . $k] = $v['business_type'];
            $data['purpose_' . $k]       = $v['purpose'];
        }
        try {
            return $this->curl(self::$domain . '/storage/preserve', 'POST', $data);
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 下载文件
     */
    public function download($url)
    {
        try {
            return $this->curl($this->getFullUrl($url), 'GET', ['token' => $this->token, 'disposition_type' => 'inline']);
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * 删除文件
     */
    public function delete($url)
    {
        $data = ['token' => $this->token];
        if (!is_array($url)) {
            $url = [$url];
        }
        foreach ($url as $k => $v) {
            $data['urls[' . $k . ']'] = $v;
        }
        try {
            return $this->curl(self::$domain . '/storages/delete', 'POST', $data);
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    //更新
    public function update($url, $filePath)
    {
        try {
            $this->delete($url);
            $res = $this->upload($filePath);
            return $res;
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    //curl
    private function curl($url, $method = 'GET', $data = [])
    {
        $ch = curl_init();
        switch ($method) {
            case 'GET':
                //拼接get参数
                $url = [] == $data ? $url : $url . '?' . http_build_query($data);
                break;
            case 'POST':
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
                break;
            case 'PUT':
            case 'DELETE':
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
            default:
                break;
        }
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        $response = curl_errno($ch) ? curl_error($ch) : curl_exec($ch);
        $info     = curl_getinfo($ch);
        curl_close($ch);
        //2xx 和 3xx 成功
        if (in_array(substr($info['http_code'], 0, 1), [2, 3])) {
            return $response;
        }
        throw new \Exception($response);
    }

    //获取绝对url
    private function getFullUrl($url)
    {
        return self::$domain . $url;
    }

    public function getToken()
    {
        return $this->token;
    }
}
