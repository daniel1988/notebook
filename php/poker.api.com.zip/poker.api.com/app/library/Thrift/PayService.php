<?php

namespace Thrift;

/**
 * Thrift 服务
 */
use Thrift\ClassLoader\ThriftClassLoader;
use Thrift\Protocol\TBinaryProtocol;
use Thrift\Transport\TFramedTransport;
use Thrift\Transport\TSocket;

class PayService
{

    protected static $instance = null;

    protected $loader = null;
    protected $pay = null;

    public $result = null;
    public $errno = null;
    public $exception = null;

    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    protected function __construct()
    {
        $directory = __DIR__ . '/UserPayInfo';

        $this->loader = new ThriftClassLoader();
        $this->loader->registerNamespace('Thrift', __DIR__ . '/');
        $this->loader->registerDefinition('user_pay_info', $directory);
        $this->loader->register();
    }

    public function getTransport($name)
    {
        $config = config("thrift.{$name}");
        $socket = new TSocket($config->host, $config->port);

        $timeout = (isset($config->timeout)) ? $config->timeout : 10;
        $socket->setSendTimeout($timeout * 1000);
        $socket->setRecvTimeout($timeout * 1000);

        $transport = new TFramedTransport($socket);
        $transport->open();

        return $transport;
    }

    // pay service client
    public function getPay()
    {
        // 每次请求前初始化结果和异常
        $this->errno = null;
        $this->result = null;
        $this->exception = null;

        if (null !== $this->pay) {
            return $this->pay;
        }

        $this->pay = new \user_pay_info\UserPayInfoServiceClient(
            new TBinaryProtocol($this->getTransport('pay'))
        );

        return $this->pay;
    }

    /**
     * 查询银行卡限额
     */
    public function getBankQuote($start_bank_name = '', $num = 16, $business_type = 0x01)
    {
        try {
            $logger = S('logger')->get(__METHOD__);
            $BatchBankPayQuotaReq = new \user_pay_info\BatchBankPayQuotaReq([
                'business_type' => $business_type,
                'start_bank_name' => $start_bank_name,
                'batch_num' => $num,
            ]);
            $logger->debug('request: ' . var_export($BatchBankPayQuotaReq, true));

            $res = $this->getPay()->BatchBankPayQuota($BatchBankPayQuotaReq);
            $logger->debug('result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res->err_no ? $res->quota_list : false;
        } catch (\Exception $e) {

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 在渠道返回绑定成功后，调用该接口
     *
     * 需要传递的参数$data
     *
     * uid              : 用户的uid
     * business_type    : 业务类型,0x01, 集合理财; 0x02, 外汇; 0x04, 股票  ?
     * pay_channel      : 支付渠道：连连支付,易宝,银联
     * bank_card_id     : 银行卡号
     * bank_name        : 银行卡名称
     * phone            : 银行卡绑定的手机号码
     * bind_status      : 绑定状态:0(未绑定), 1(已绑定)
     * contract_no      : 签约号(作为一个唯一标识,根据它到支付渠道可以查出用户名,帐号,电话等),连连有,易宝没有, 银联未知
     *
     * 需要传递的参数$user
     * uid              : 用户的uid
     * name             : 姓名
     * identity_id      : 身份证号
     * pay_password     : 支付密码
     */
    public function bindUserPayInfo(array $data, $user = [], $business_type = 0x01)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $data['business_type'] = isset($data['business_type']) ?: $business_type;
            $BankCardPayInfo = new \user_pay_info\BankCardPayInfo($data);
            $info = ['card_pay_info' => $BankCardPayInfo];
            if ($user) {
                $info['user_base_info'] = new \user_pay_info\UserBaseInfo($user);
            }

            $BindUserPayInfoReq = new \user_pay_info\BindUserPayInfoReq($info);
            $logger->debug('request: ' . var_export($BindUserPayInfoReq, true));

            $res = $this->getPay()->BindUserPayInfo($BindUserPayInfoReq);
            $logger->debug('result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res ? true : $res;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 解除用户的绑定信息
     */
    public function unbindUserPayInfo($uid, $data, $business_type = 0x01, $force = false)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $BankCardPayChannel = [];
            $BankCardPayChannel[] = new \user_pay_info\BankCardPayChannel([
                'business_type' => $business_type,
                'bank_card_id' => (string) $data['bank_card_id'],
                'pay_channel' => $data['pay_channel'],
            ]);
            $UnbindUserPayInfoReq = new \user_pay_info\UnbindUserPayInfoReq([
                'uid' => $uid,
                'bound_pay_list' => $BankCardPayChannel,
                'if_force_unbind' => (bool) $force,
            ]);
            $logger->debug('request: ' . var_export($UnbindUserPayInfoReq, true));

            $res = $this->getPay()->UnbindUserPayInfo($UnbindUserPayInfoReq);
            $logger->debug('result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res ? true : $res;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 获取用户的基本信息，姓名，身份证号码
     */
    public function getUserInfo($uid)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $QueryUserBaseInfoReq = new \user_pay_info\QueryUserBaseInfoReq(['uid' => $uid]);
            $logger->debug('request: ' . var_export($QueryUserBaseInfoReq, true));

            $res = $this->getPay()->QueryUserBaseInfo($QueryUserBaseInfoReq);
            $logger->debug('result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res->err_no ? $res->user_base_info : false;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 查询绑定的银行卡额度信息
     */
    public function getUserBankQuote($uid, $business_type = 0x01)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $QueryBoundBankCardQuotaReq = new \user_pay_info\QueryBoundBankCardQuotaReq([
                'uid' => $uid,
                'business_type' => $business_type,
            ]);
            $logger->debug('request: ' . var_export($QueryBoundBankCardQuotaReq, true));

            $res = $this->getPay()->QueryBoundBankCardQuota($QueryBoundBankCardQuotaReq);
            $logger->debug('result: ' . var_export($res, true));
            $card = new \stdClass;
            $card->cardInfo = [];
            $card->current_card = false;
            if ($res && \user_pay_info\Errno::SUCCESS == $res->err_no &&
                isset($res->card_pay_list) &&
                $res->card_pay_list) {
                $cards = $res->card_pay_list;
                if ($cards && isset($cards[0])) {
                    //当前只支持绑定一张银行卡，默认第一张
                    $card->current_card = $cards[0];
                    $card->current_card->card_no4 = substr($card->current_card->bank_card_id, -4, 4);
                    $card->current_card->card_no_hide = substr($card->current_card->bank_card_id, 0, 4) . '****' . substr($card->current_card->bank_card_id, -4);
                }
            }

            return $card;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 查询用户支付绑定信息
     */
    public function getUserPayBindInfo($uid, $business_type = 0x01)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $QueryUserPayBindInfoReq = new \user_pay_info\QueryUserPayBindInfoReq([
                'uid' => $uid,
                'business_type' => $business_type,
            ]);
            $logger->debug('request: ' . var_export($QueryUserPayBindInfoReq, true));

            $res = $this->getPay()->QueryUserPayBindInfo($QueryUserPayBindInfoReq);
            $logger->debug('result: ' . var_export($res, true));
            $card = new \stdClass;
            $card->llpay = false;
            $card->yeepay = false;
            $card->unionpay = false;
            $card->hasBindChannels = [];
            $card->user = false;
            $card->hasBindPayChannel = false;
            $card->cardInfo = [];
            if ($res && \user_pay_info\Errno::SUCCESS == $res->err_no) {
                $card->user = (isset($res->user_base_info)) ? $res->user_base_info : false;

                if (isset($res->card_pay_info_list) && $res->card_pay_info_list) {
                    $cards = $res->card_pay_info_list;
                    foreach ($cards as $card_info) {
                        if (1 === $card_info->bind_status) {
                            $card_info->card_no = $card_info->bank_card_id;
                            $card_info->card_no4 = substr($card_info->bank_card_id, -4, 4);
                            $card_info->card_no_hide = substr($card_info->bank_card_id, 0, 4) . '****' . substr($card_info->bank_card_id, -4);
                            //保存已经绑定过的渠道
                            $card->hasBindChannels[] = $card_info->pay_channel;
                            $card->cardInfo[] = $card_info;
                            switch ($card_info->pay_channel) {
                                case \user_pay_info\PayChannel::LIANLIAN:
                                    $card->llpay = $card_info;
                                    break;
                                case \user_pay_info\PayChannel::YIBAO:
                                    $card->yeepay = $card_info;
                                    break;
                                case \user_pay_info\PayChannel::LLPAY_EBANK:
                                    $card->llpayebank = $card_info;
                                    break;
                                case \user_pay_info\PayChannel::YEEPAY_EBANK:
                                    $card->yeepayebank = $card_info;
                                    break;
                                case \user_pay_info\PayChannel::YINLIAN:
                                    $card->unionpay = $card_info;
                                    break;
                                default:
                                    //do nothing
                                    break;
                            }
                        }
                    }
                }
            }
            //任意一个支付渠道即可
            if ($card->llpay ||
                $card->yeepay ||
                $card->unionpay
            ) {
                $card->hasBindPayChannel = true;
            }
            $logger->debug('card: ' . var_export($card, true));

            return $card;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 根据银行卡获取可以绑定的渠道
     *
     * 需要传递的参数$user
     * uid              : 用户的uid
     * bank_name        : 银行名称
     * business_type    : 业务类型,0x01, 集合理财; 0x02, 外汇; 0x04, 股票
     * recharge_amount  : 充值金额
     */
    public function getCanBindChannel($uid, $bank_name, $card_no, $recharge_amount = 0, $business_type = 0x01)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $QueryUsablePayBindReq = new \user_pay_info\QueryUsablePayBindReq([
                'uid' => $uid,
                'bank_name' => $bank_name,
                'bank_card_id' => $card_no,
                'business_type' => $business_type,
                'recharge_amount' => $recharge_amount,
            ]);
            $logger->debug('request: ' . var_export($QueryUsablePayBindReq, true));

            $res = $this->getPay()->QueryUsablePayBind($QueryUsablePayBindReq);
            $logger->debug('result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res->err_no ? $res->card_pay : $res->err_no;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 充值接口
     *
     * 需要传递的参数$data
     *
     * uid              : 用户的uid
     * business_type    : 业务类型,0x01, 集合理财; 0x02, 外汇; 0x04, 股票
     * pay_channel      : 支付渠道：连连支付,易宝,银联
     * bank_card_id     : 银行卡号
     * bank_name        : 银行卡名称
     * amount           : 充值金额
     * transaction_id   : 交易唯一id
     * market_channel   : 市场渠道
     *
     * 需要传递的参数$operate
     * operate          : 1(充值), 2(撤销充值). 目前仅支持充值.
     */
    public function doOneRecharge($data, $operate = 1, $business_type = 0x01)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            if (!isset($data['business_type'])) {
                $data['business_type'] = $business_type;
            }
            $OneRecharge = new \user_pay_info\OneRecharge($data);

            $DoOneRechargeReq = new \user_pay_info\DoOneRechargeReq([
                'action' => $OneRecharge,
                'operate' => $operate,
            ]);
            $logger->debug('request: ' . var_export($DoOneRechargeReq, true));

            $res = $this->getPay()->DoOneRecharge($DoOneRechargeReq);
            $logger->debug('result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res || \user_pay_info\Errno::CIP_TRANSACTION_ID_DUP === $res ? true : false;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 验证用户的支付密码
     */
    public function verifyPayPasswd($uid, $pay_passwd)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $VerifyPayPasswordReq = new \user_pay_info\VerifyPayPasswordReq([
                'uid' => $uid,
                'pay_password' => $pay_passwd,
            ]);
            $logger->debug('request: ' . var_export($VerifyPayPasswordReq, true));

            $res = $this->getPay()->VerifyPayPassword($VerifyPayPasswordReq);
            $logger->debug('result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res ? true : false;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 重置用户的支付密码
     */
    public function resetPayPasswd($uid, $pay_passwd, $old_pay_passwd = '')
    {
        try {
            $ResetPayPasswordReq = new \user_pay_info\ResetPayPasswordReq([
                'uid' => $uid,
                'old_pay_password' => $old_pay_passwd,
                'pay_password' => $pay_passwd,
            ]);
            write_log(__FUNCTION__, 'request: ' . var_export($ResetPayPasswordReq, true));

            $res = $this->getPay()->ResetPayPassword($ResetPayPasswordReq);
            write_log(__FUNCTION__, 'result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res->err_no ? true : false;
        } catch (\Exception $tx) {
            $err = 'TEception: ' . $tx->getMessage();
            write_log(__FUNCTION__, $err);

            return false;
        }
    }

    /**
     * 检查用户的银行卡或者身份证，是否已经绑定
     */
    public function verifyBindInfo($uid, $id_card, $card_no)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $UserIDBankCardPair = new \user_pay_info\UserIDBankCardPair([
                'uid' => $uid,
                'user_id_card' => (string) $id_card,
                'bank_card_id' => (string) $card_no,
            ]);
            $QueryUserIDBankCardBoundReq = new \user_pay_info\QueryUserIDBankCardBoundReq([
                'uid_bank_card_pair' => $UserIDBankCardPair,
            ]);
            $logger->debug('request: ' . var_export($QueryUserIDBankCardBoundReq, true));

            $res = $this->getPay()->QueryUserIDBankCardBound($QueryUserIDBankCardBoundReq);
            $logger->debug('result: ' . var_export($res, true));

            return $res->err_no;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 获取银行卡的基本信息
     */
    public function getCardBaseInfo($uid, $business_type = 0x01)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $QueryBoundBankCardBaseInfoReq = new \user_pay_info\QueryBoundBankCardBaseInfoReq([
                'uid' => $uid,
                'business_type' => $business_type,
            ]);
            $logger->debug('request: ' . var_export($QueryBoundBankCardBaseInfoReq, true));

            $res = $this->getPay()->QueryBoundBankCardBaseInfo($QueryBoundBankCardBaseInfoReq);
            $logger('result: ' . var_export($res, true));
            $card = new \stdClass;
            $card->cardInfo = [];
            $card->current_card = false;
            if ($res && \user_pay_info\Errno::SUCCESS == $res->err_no &&
                isset($res->bank_card_list) &&
                $res->bank_card_list) {
                $cards = $res->bank_card_list;
                if ($cards && isset($cards[0])) {
                    $card->current_card = $cards[0];
                    //当前只支持绑定一张银行卡，默认第一张
                    $card->current_card->card_no4 = substr($card->current_card->bank_card_id, -4, 4);
                    $card->current_card->card_no_hide = substr($card->current_card->bank_card_id, 0, 4) . '****' . substr($card->current_card->bank_card_id, -4);
                }
            }

            return $card;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 更新银行卡的基本信息
     */
    public function updateCardBaseInfo($uid, $data)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $BoundBankCardBaseInfo = new \user_pay_info\BoundBankCardBaseInfo($data);
            $ModifyBoundBankCardBaseInfoReq = new \user_pay_info\ModifyBoundBankCardBaseInfoReq([
                'uid' => $uid,
                'bank_card' => $BoundBankCardBaseInfo,
            ]);
            $logger->debug('request: ' . var_export($ModifyBoundBankCardBaseInfoReq, true));

            $res = $this->getPay()->ModifyBoundBankCardBaseInfo($ModifyBoundBankCardBaseInfoReq);
            $logger->debug('result: ' . var_export($res, true));

            return \user_pay_info\Errno::SUCCESS === $res;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 获取银行卡的别名信息
     */
    public function getBankAlias($bank_name)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $QueryBankAliasReq = new \user_pay_info\QueryBankAliasReq([
                'bank_name' => $bank_name,
            ]);
            $logger->debug('request: ' . var_export($QueryBankAliasReq, true));

            $res = $this->getPay()->QueryBankAlias($QueryBankAliasReq);
            $logger->debug('result: ' . var_export($res, true));

            return (\user_pay_info\Errno::SUCCESS === $res->err_no) ? $res->bank_alias : false;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 获取所有可用的支付渠道
     */
    public function getPayChannels()
    {
        $names = \user_pay_info\PayChannel::$__names;
        $names = array_flip($names);
        $channels = [];
        foreach ($names as $key => $value) {
            $channels[strtolower($key)] = $value;
        }

        return $channels;
    }

    /**
     * 获取所有可用的支付渠道
     */
    public function getBusiness()
    {
        $names = \user_pay_info\BusinessType::$__names;
        $names = array_flip($names);
        $business = [];
        foreach ($names as $key => $value) {
            $business[strtolower($key)] = $value;
        }

        return $business;
    }

    /**
     * 提现操作
     */
    public function doWithdrawal($data)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $UserIOMoneyInfo = new \user_pay_info\UserIOMoneyInfo($data);
            $logger->debug('request: ' . var_export($UserIOMoneyInfo, true));

            $res = $this->getPay()->UserAcountMoneyOut($UserIOMoneyInfo);

            $result = new \stdClass;
            switch ($res) {
                case \user_pay_info\Errno::SUCCESS:
                    $result->status = true;
                    $result->msg = __('提现成功');
                    break;
                case \user_pay_info\Errno::FORBAG_HAVE_NO_COMPLETE_ORDER:
                    # code...
                    $result->status = false;
                    $result->msg = __('您已提现过一笔，请等待处理完毕再重试');
                    break;
                default:
                    # code...
                    $result->status = false;
                    $result->msg = __('提现操作失败，请稍后再试');
                    break;
            }

            $logger->debug('res:' . var_export($res, true) . ',result'
                . var_export($result, true));

            return $result;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            $result = new \stdClass;
            $result->status = false;
            $result->msg = __('提现操作失败，请稍后再试');

            return $result;
        }
    }

    /**
     * 获取可以出金的银行卡
     */
    public function getOutFundCard($uid)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $UserWithdrawCardRequest = new \user_pay_info\UserWithdrawCardRequest([
                'uid' => (int) $uid,
            ]);
            $logger->debug('request: ' . var_export($UserWithdrawCardRequest, true));

            $res = $this->getPay()->QueryUserWithdrawCard($UserWithdrawCardRequest);
            $logger->debug('result: ' . var_export($res, true));

            if (\user_pay_info\Errno::SUCCESS === $res->err_no) {
                $res->card_info->card_no_hide = substr($res->card_info->bank_card_id, 0, 4) . '****' . substr($res->card_info->bank_card_id, -4);
                $res->card_info->card_no4 = substr($res->card_info->bank_card_id, -4);

                return $res->card_info;
            }

            return false;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /*
     * 获取网银列表
     */
    public function getEbankList($uid = 0)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $EBankRequest = new \user_pay_info\EBankRequest([
                'uid' => $uid,
            ]);
            $logger->debug('request: ' . var_export($EBankRequest, true));

            $res = $this->getPay()->QueryAvalEBank($EBankRequest);
            $logger->debug('result: ' . var_export($res, true));
            if (\user_pay_info\Errno::SUCCESS === $res->err_no && isset($res->all_ebank_list)) {
                $list = $res->all_ebank_list;
                $banks = [];
                foreach ($list as $bank) {
                    if (isset($bank->bank_name) && !isset($banks[$bank->bank_name])) {
                        $banks[$bank->bank_name] = $bank;
                    }
                }
                $logger('banks: ' . var_export($banks, true));

                return $banks;
            }

            return false;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 更新或者是添加 用户身份证的信息
     */
    public function updateUserBaseInfo($uid, $name, $id_card)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $req = new \user_pay_info\UserBaseInfo([
                'uid' => (int) $uid,
                'name' => $name,
                'identity_id' => $id_card,
            ]);
            $logger->debug('request:' . var_export($req, true));
            $res = $this->getPay()->UpdateUserBaseInfo($req);
            $logger->debug('response:' . var_export($res, true));

            return (\user_pay_info\Errno::SUCCESS === $res->errinfo->err_no) ? true : $res->user_base_info;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }
}
