<?php

namespace Thrift;

/**
 * Thrift 服务
 */
use Thrift\ClassLoader\ThriftClassLoader;
use Thrift\Protocol\TBinaryProtocol;
use Thrift\Transport\TFramedTransport;
use Thrift\Transport\TSocket;

class StockFollower
{

    public static $instance = null;

    protected $loader = null;
    protected $client = null;

    public $result = null;
    public $errno = null;
    public $exception = null;

    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    public function __construct()
    {
        $directory = __DIR__ . '/StockFollower';

        $this->loader = new ThriftClassLoader();
        $this->loader->registerNamespace('Thrift', __DIR__ . '/');
        $this->loader->registerDefinition('follower_info', $directory);
        $this->loader->registerDefinition('stock_copy_master_common', $directory);
        $this->loader->register();
    }

    public function getTransport($timeout = 10)
    {
        $config = config('thrift.StockFollower');
        $socket = new TSocket($config->host, $config->port);

        if (null !== $timeout) {
            $socket->setSendTimeout($timeout * 1000);
            $socket->setRecvTimeout($timeout * 1000);
        }

        $transport = new TFramedTransport($socket);
        $transport->open();

        return $transport;
    }

    public function getClient()
    {
        // 每次请求前初始化结果和异常
        $this->errno = null;
        $this->result = null;
        $this->exception = null;

        if (null !== $this->client) {
            return $this->client;
        }

        $this->client = new \follower_info\FollowerInfoServiceClient(
            new TBinaryProtocol($this->getTransport())
        );

        return $this->client;
    }

    public function reconnect()
    {
        $this->client = null;

        return $this;
    }

    // stockcopycommon.FollowerFundResp GetFollowerFundInfo(1: required stockcopycommon.UserBaseInfo useinfo);
    //
    // struct UserBaseInfo {
    //   1: optional string user_name = "",
    //   2: required string user_id,
    //   3: required i32 broker_id,
    //   4: required string broker_user_id,
    //   5: optional string broker_user_passwd_encoded = "",
    // }
    public function getFundInfo($uid)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $req = new \stock_copy_master_common\UserBaseInfo([
                'user_id' => (string) $uid,
                'broker_id' => '',
                'broker_user_id' => '',
            ]);
            $logger->debug('Request: ' . var_export($req, true));

            $res = $this->getClient()->GetFollowerFundInfo($req);
            $logger->debug('Response: ' . var_export($res, true));

            $this->errno = $res->err->err_no;
            $this->result = $res;

            if ($res->err->err_no == \stock_copy_master_common\StockErrno::SUCCESS) {
                return $res;
            }

            throw new \Exception($res->err->err_msg, (int) $res->err->err_no);
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }
}
