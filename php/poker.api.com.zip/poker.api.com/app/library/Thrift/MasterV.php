<?php

namespace Thrift;

/**
 * Thrift 服务
 */
use Thrift\ClassLoader\ThriftClassLoader;
use Thrift\Protocol\TBinaryProtocol;
use Thrift\Transport\TFramedTransport;
use Thrift\Transport\TSocket;

class MasterV
{
    protected static $instance = null;

    protected $loader = null;
    protected $base = null;
    protected $collect = null;
    protected $client = null;
    protected $proxy = null;
    protected $cow = null;
    protected $promotion = null;

    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    protected function __construct()
    {
        $directory = __DIR__ . '/MasterV';

        $this->loader = new ThriftClassLoader();
        $this->loader->registerNamespace('Thrift', __DIR__ . '/');
        $this->loader->registerDefinition('follower_info', $directory);
        $this->loader->registerDefinition('stock_copy_master_common', $directory);
        $this->loader->registerDefinition('stock_copy_master_share', $directory);
        $this->loader->register();
    }

    public function getTransport($thrift = 'settlement')
    {
        $config = C('thrift.' . $thrift);
        $socket = new TSocket($config->host, $config->port);

        if (isset($config->timeout)) {
            $socket->setSendTimeout($config->timeout * 1000);
            $socket->setRecvTimeout($config->timeout * 1000);
        }

        $transport = new TFramedTransport($socket);
        $transport->open();

        return $transport;
    }

    // Follower service client
    public function getFollower($thrift = 'follower_info')
    {
        if (null !== $this->base) {
            return $this->base;
        }

        $this->base = new \follower_info\FollowerInfoServiceClient(
            new TBinaryProtocol($this->getTransport($thrift))
        );

        return $this->base;
    }

    // proxy service client
    public function getMasterShare($thrift = 'master_freshman')
    {

        if (null !== $this->collect) {
            return $this->collect;
        }
        $this->collect = new \stock_copy_master_share\ProfitSharingServiceClient(
            new TBinaryProtocol($this->getTransport($thrift))
        );

        return $this->collect;
    }

    // 根据用户uids集  获取 对应的用户余额
    public function getHkLeftBalance(array $uids = [], $ret_rate = false)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $req = new \stock_copy_master_common\UserAvailableFundReq([
                'user_id_list' => $uids,
            ]);
            $logger->debug('request: ' . var_export($req, true));
            $res = $this->getFollower()->GetUserAvailableFund($req);
            $logger->debug('result: ' . var_export($res, true));

            return (!$ret_rate) ? $res->available_fund_info : ['available_fund_info' => $res->available_fund_info, 'rate' => $res->us_to_hk_rate];
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }

    /**
     * 获取小白用户 实时的浮动分成
     */
    public function getFollowerFloatProfitSharing($uids = [])
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $req = new \stock_copy_master_share\FollowerFloatProfitSharingReq([
                'follower_ids' => $uids,
            ]);
            $logger->debug('request: ' . implode(',', $uids));
            $res = $this->getMasterShare()->FollowerFloatProfitSharing($req);
            $logger->debug('result: ' . var_export($res, true));
            if (!$res->err || !$res->err->err_no || \stock_copy_master_common\StockErrno::SUCCESS != $res->err->err_no) {
                return false;
            }

            return $res->float_profits;
        } catch (\Exception $e) {
            $this->exception = $e;

            $err = 'TEception: ' . $e->getMessage();
            $logger->error('Exception: ' . $e->getMessage());

            return false;
        }
    }
}
