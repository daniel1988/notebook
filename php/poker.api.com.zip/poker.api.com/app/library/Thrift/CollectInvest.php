<?php

namespace Thrift;

/**
 * Thrift 服务
 */
use Thrift\ClassLoader\ThriftClassLoader;
use Thrift\Protocol\TBinaryProtocol;
use Thrift\Transport\TFramedTransport;
use Thrift\Transport\TSocket;

class CollectInvest
{

    public static $instance = null;

    protected $loader = null;
    protected $client = null;

    public static function instance()
    {
        if (null === self::$instance) {
            self::$instance = new self;
        }

        return self::$instance;
    }

    public function __construct()
    {
        $directory = __DIR__ . '/CollectInvest';

        $this->loader = new ThriftClassLoader();
        $this->loader->registerNamespace('Thrift', __DIR__ . '/');
        $this->loader->registerDefinition('collectinvest', $directory);
        $this->loader->registerDefinition('social_trading', $directory);
        $this->loader->registerDefinition('formax_auth', $directory);
        $this->loader->register();
    }

    public function getTransport($name, $timeout = 10000)
    {
        $config = config("thrift.$name");
        $socket = new TSocket($config->host, $config->port);

        if (null !== $timeout) {
            $socket->setSendTimeout($timeout);
            $socket->setRecvTimeout($timeout);
        }

        $transport = new TFramedTransport($socket);
        $transport->open();

        return $transport;
    }

    // proxy service client
    public function getClient()
    {
        if (null !== $this->client) {
            return $this->client;
        }

        $this->client = new \collectinvest\CollectInvestServiceClient(
            new TBinaryProtocol($this->getTransport('collectinvest'))
        );

        return $this->client;
    }

    // 注册量 有效安装数
    // GetLineExtensionStatInfoReturn GetLineExtensionStatInfo(1: required GetLineExtensionStatInfoRequest req);
    public function getRegnum($fromid)
    {
        try {
            $logger = S('logger')->get(__METHOD__);

            $req = new \collectinvest\GetLineExtensionStatInfoRequest([
                'line_extension_id_list' => $fromid,
            ]);
            $logger->debug('req: ' . var_export($req, true));

            $res = $this->getClient()->GetLineExtensionStatInfo($req);

            $logger->debug('result: ' . var_export($res, true));

            return $res;
        } catch (\Exception $tx) {
            $err = 'TEception: ' . $tx->getMessage();
            $logger->error($err);

            return false;
        }
    }
}
