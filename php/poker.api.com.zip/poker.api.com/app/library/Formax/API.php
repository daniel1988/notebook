<?php

namespace Formax;

class API extends \Phalcon\DI\Injectable
{

    /**
     * 通用错误代码定义
     */
    const SUCCEED = 200;           // 响应成功
    const INVALID_REQUEST = 404;   // 无效请求
    const INTERNAL_ERROR = 500;    // 内部错误
    const APP_ID_ERROR = 600;      // APP ID 错误或者未指定
    const APP_KEY_ERROR = 601;     // APP 密钥校验失败
    const APP_DISABLED = 602;      // APP 禁止接入
    const API_NOT_FOUND = 603;     // 接口不存在
    const API_FORBIDDEN = 604;     // 无权请求该接口
    const USER_NOT_FOUND = 605;    // 操作人员不存在
    const NOT_APP_USER = 606;      // 非当前 app 操作人员
    const MISSING_PARAMETER = 607; // 缺少必要参数
    const DB_ERROR = 608;          // 数据库错误
    const SERVICE_FAILED = 609;    // 后端服务错误(thrift, api, rpc ...)
    const NO_RESPONSE = 610;       // 未返回响应结果

    /**
     * API 响应数据 (JSON格式)
     *
     * @param integer $code    响应代码
     * @param string  $message 响应消息
     * @param mixed   $data    响应数据
     */
    public function response($code, $message = null, $data = null)
    {
        $this->response
            ->setJsonContent([
                'code' => (int) $code,
                'message' => $message,
                'data' => $data,
                'timestamp' => time(),
            ], defined('JSON_PRETTY_PRINT') ? JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES : null)
            ->send();
        exit;
    }

    /**
     * 响应错误信息
     *
     * @param string $message
     * @param array  $data
     */
    public function error($message = null, $data = null)
    {
        $this->response(self::INTERNAL_ERROR, $message, $data);
    }

    /**
     * 响应成功信息
     *
     * @param string $message
     * @param array  $data
     */
    public function success($message = null, $data = null)
    {
        $this->response(self::SUCCEED, $message, $data);
    }
}
