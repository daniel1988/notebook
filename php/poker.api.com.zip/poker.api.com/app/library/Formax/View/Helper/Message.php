<?php

namespace Formax\View\Helper;

use Phalcon\Session\Bag as SessionBag;

/**
 * 视图助手 - 输出响应信息
 *
 * 示例：
 *
 *     $helper = new \Formax\View\Helper\Message;
 *     $helper->success('操作执行成功！')->addLink(link_to('/', '首页'));
 *     $helper->error('操作失败！');
 */
class Message extends \Phalcon\DI\Injectable
{

    const MESSAGE = 'message';
    const SUCCESS = 'success';
    const ERROR = 'error';
    const WARNING = 'warning';

    /**
     * SessionBag
     *
     * @var \Phalcon\Session\Bag
     */
    public $session = null;

    /**
     * 构造方法
     */
    public function __construct()
    {
        $this->session = new SessionBag(__CLASS__);
        $this->session->initialize();
    }

    /**
     * 输出普通消息
     *
     * @param string $message
     * @param mixed  $links
     */
    public function message($message, $links = [])
    {
        return $this->redirect([
            'type' => self::MESSAGE,
            'title' => __('Message !'),
            'message' => __($message),
            'links' => $links,
        ]);
    }

    /**
     * 输出操作成功消息
     *
     * @param string $message
     * @param mixed  $links
     */
    public function success($message, $links = [])
    {
        return $this->redirect([
            'type' => self::SUCCESS,
            'title' => __('Success !'),
            'message' => __($message),
            'links' => $links,
        ]);
    }

    /**
     * 输出操作失败消息
     *
     * @param string $message
     * @param mixed  $links
     */
    public function error($message, $links = [])
    {
        return $this->redirect([
            'type' => self::ERROR,
            'title' => __('Error !'),
            'message' => __($message),
            'links' => $links,
        ]);
    }

    /**
     * 输出警告消息
     *
     * @param string $message
     * @param mixed  $links
     */
    public function warning($message, $links = [])
    {
        return $this->redirect([
            'type' => self::WARNING,
            'title' => __('Warning !'),
            'message' => __($message),
            'links' => $links,
        ]);
    }

    /**
     * redirect 消息输出页面
     *
     * @param array $data
     */
    public function redirect(array $data)
    {
        foreach ($data as $key => $value) {
            $this->session->$key = $value;
        }

        $this->response->redirect('helper/message', false, 302)
            ->sendHeaders();

        exit();
    }

    /**
     * 获取session数据
     *
     * @return array
     */
    public function getSession()
    {
        return $this->session->getIterator()->getArrayCopy();
    }

    /**
     * 销毁session数据
     */
    public function destroySession()
    {
        return $this->session->destroy();
    }
}
