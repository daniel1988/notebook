<?php

namespace Formax;

use CRM\AccessRules;
use CRM\Roles;
use Zend\Permissions\Acl\Acl as ZendAcl;
use Zend\Permissions\Acl\Resource\GenericResource as ZendAclResource;
use Zend\Permissions\Acl\Role\GenericRole as ZendAclRole;

class Acl
{
    /**
     * @var string
     */
    public static $cacheKey = 'ZENDACLDATA';

    /**
     * @var \Zend\Permissions\Acl\Acl
     */
    protected $acl = null;

    /**
     * @var array
     */
    protected $userRoles = [];

    /**
     * @var string
     */
    protected $userRole = null;

    /**
     * @var Formax\Logger
     */
    protected $logger = null;

    /**
     * 构造方法
     */
    public function __construct()
    {
        $this->logger = service('logger')->get('acl');

        if (!$acl = cache_get(self::$cacheKey)) {
            $acl = $this->initAcl();
        }

        $this->acl = $acl;
    }

    /**
     * 初始化 Acl
     *
     * @return \Zend\Permissions\Acl\Acl
     */
    protected function initAcl()
    {
        $acl = new ZendAcl;

        // 初始化
        $this->initResources($acl);
        $this->initRoles($acl);

        // 缓存30天
        cache_save(self::$cacheKey, $acl, 86400 * 30);

        return $acl;
    }

    /**
     * 初始化 Acl 资源
     *
     * @param \Zend\Permissions\Acl\Acl $acl
     */
    protected function initResources(&$acl)
    {
        // 根资源
        $root = '*';
        $acl->addResource(new ZendAclResource($root));
        $this->logger->debug("\$acl->addResource(new ZendAclResource($root))");

        foreach (C('acl.resource') as $category => $resources) {
            $acl->addResource(new ZendAclResource($category), $root);
            $this->logger->debug("\$acl->addResource(new ZendAclResource($category))");

            foreach ($resources as $resource => $actions) {
                $acl->addResource(new ZendAclResource("$category.$resource"), $category);
                $this->logger->debug("\$acl->addResource(new ZendAclResource($category.$resource), $category)");
            }
        }
    }

    /**
     * 初始化 Acl 角色
     *
     * @param \Zend\Permissions\Acl\Acl $acl
     */
    protected function initRoles(&$acl)
    {
        // 根角色
        $root = '*';
        $acl->addRole(new ZendAclRole($root));
        $this->logger->debug("\$acl->addRole(new ZendAclRole($root))");
        $this->initRules($acl, $root);

        // 角色组
        foreach (C('acl.group') as $group) {
            $acl->addRole(new ZendAclRole($group), $root);
            $this->logger->debug("\$acl->addRole(new ZendAclRole($group))");
            $this->initRules($acl, $group);
        }

        $roles = array_group(Roles::getAll(), 'role_group');

        // 子角色
        foreach (C('acl.group') as $group) {
            foreach (A($roles, $group, []) as $row) {
                // 继承 Group Role
                $role = $this->formatRoleName($row['role_id']);
                $acl->addRole(new ZendAclRole($role), $row['role_group']);
                $this->logger->debug("\$acl->addRole(new ZendAclRole($role), {$row['role_group']})");
                $this->initRules($acl, $role);
            }
        }
    }

    /**
     * 初始化 Acl 访问规则
     *
     * @param \Zend\Permissions\Acl\Acl $acl
     * @param string                    $role
     */
    protected function initRules(&$acl, $role)
    {
        // 取出规则，数字大的最后执行，因此会覆盖之前的规则
        $rules = AccessRules::find([
            "role = '$role'",
            'order' => 'priority, rule_id',
        ]);

        foreach ($rules as $rule) {
            $method = $rule->allowed ? 'allow' : 'deny';
            $actions = explode(',', $rule->actions);

            foreach ($actions as $action) {
                if ($acl->hasRole($rule->role) && $acl->hasResource($rule->resource)) {
                    $acl->$method($rule->role, $rule->resource, $action === '*' ? null : $action);
                    $this->logger->debug("\$acl->$method($rule->role, $rule->resource, $action)");
                }
            }
        }
    }

    /**
     * 获取 Acl 实例
     *
     * @return \Zend\Permissions\Acl\Acl
     */
    public function getAcl()
    {
        return $this->acl;
    }

    /**
     * 刷新 Acl 缓存
     *
     * @return \Formax\Acl
     */
    public function refresh()
    {
        cache_del(self::$cacheKey);

        return $this;
    }

    /**
     * 创建一个独立的角色，继承自所属的所有角色
     *
     * @param  integer       $userId
     * @param  array         $roles
     * @return \Formax\Acl
     */
    public function setUserRoles($userId, array $roles)
    {
        $roles = $this->formatRoleName($roles);

        // 添加以用户 id 建立的角色
        $userRole = $this->userRoleName((int) $userId);

        // 初始化用户角色
        if (!$this->acl->hasRole($userRole)) {
            $this->acl->addRole(new ZendAclRole($userRole), $roles);
            $this->logger->debug("\$acl->addRole(new ZendAclRole($userRole), [" . implode($roles, ',') . '])');

            $this->initRules($this->acl, $userRole);
        }

        array_push($roles, $userRole);

        $this->userRoles = $roles;
        $this->userRole = $userRole;

        return $this;
    }

    /**
     * 获取用户角色
     *
     * @return array
     */
    public function getUserRoles()
    {
        return $this->userRoles;
    }

    /**
     * 判断是否拥有权限，只要拥有其中的一个权限，就返回 true
     *
     *     $acl->hasAllow(
     *         'system.user!list',
     *         'system.user!del'
     *     );
     *
     * @param  string    $privileges
     * @return boolean
     */
    public function hasAllow($privileges)
    {
        $privileges = func_get_args();

        foreach ($privileges as $privilege) {
            if ($this->isAllow($privilege)) {
                return true;
            }
        }

        return false;
    }

    /**
     * 判断是否拥有权限，只要其中一个没有权限，就返回 false
     *
     *     $acl->isAllow(
     *         'system.user!list'
     *         'system.user!del',
     *     );
     *
     * @param  string    $privileges
     * @return boolean
     */
    public function isAllow($privileges)
    {
        /**
         * @var array
         */
        static $cached = [];

        // 获得角色
        $roles = $this->getUserRoles();
        $acl = $this->acl;

        if (empty($roles)) {
            return false;
        }

        foreach (func_get_args() as $privilege) {
            if (isset($cached[$privilege])) {
                if (!$cached[$privilege]) {
                    return false;
                }

                continue;
            }

            // 解析 resource & action
            if (strpos($privilege, '!') === false) {
                $resource = $privilege;
                $action = null;
            } else {
                list($resource, $action) = explode('!', $privilege);
                $action === '*' && $action = null;
            }

            $cached[$privilege] = false;

            if ($acl->hasResource($resource)
                && $acl->isAllowed($this->userRole, $resource, $action)) {
                $cached[$privilege] = true;
            }

            if (!$cached[$privilege]) {
                return false;
            }
        }

        return true;
    }

    /**
     * 将角色 id 转换为角色名
     *
     * @param  string   $roleId
     * @return string
     */
    public function formatRoleName($role)
    {
        if (is_array($role)) {
            return array_map([$this, __FUNCTION__], $role);
        }

        return is_numeric($role) ? 'ROLE_' . $role : $role;
    }

    /**
     * 将用户 id 转换为角色名
     *
     * @param  string   $userId
     * @return string
     */
    public function userRoleName($user)
    {
        if (is_array($user)) {
            return array_map([$this, __FUNCTION__], $user);
        }

        return is_numeric($user) ? 'USER_' . $user : $user;
    }
}
