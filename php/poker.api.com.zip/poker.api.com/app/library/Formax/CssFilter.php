<?php

namespace Formax;

use Phalcon\Assets\FilterInterface;

class CssFilter implements FilterInterface
{

    public function filter($contents)
    {
        if (DEVELOPMENT) {
            return $contents;
        }

        // 将 /js_src/ 替换为 /js/
        return str_replace('/js_src/', '/js/', $contents);
    }
}
