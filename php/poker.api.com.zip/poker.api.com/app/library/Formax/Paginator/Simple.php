<?php

namespace Formax\Paginator;

/**
 * 简单分页器
 *
 * @example
 *      $paginator = new \Formax\Paginator\Simple(array(
 *           "item"  => array(...)
 *           "total" => 5,
 *           "limit" => 2,
 *       ));
 *      $page = $paginator->getPaginate();
 */
class Simple implements \Phalcon\Paginator\AdapterInterface
{

    protected $_config = [];

    /**
     * Adapter constructor
     *
     * @param array $config
     */
    public function __construct(array $config)
    {
        if (!isset($config['total'])) {
            throw new Exception("Parameter 'total' is required");
        }

        if (!isset($config['limit'])) {
            throw new Exception("Parameter 'limit' is required");
        }

        $this->_config = $config;
    }

    /**
     * Set the current page number
     *
     * @param integer $page
     */
    public function setCurrentPage($page)
    {
        $this->_config['page'] = (int) $page;
    }

    /**
     * Returns a slice of the resultset to show in the pagination
     *
     * @return \stdClass
     */
    public function getPaginate()
    {
        $items = isset($this->_config['items']) ? $this->_config['items'] : [];
        $page = isset($this->_config['page']) ? (int) $this->_config['page'] : 1;
        $total = (int) $this->_config['total'];
        $limit = (int) $this->_config['limit'];

        $items = is_array($items) ? $items : [];
        $page = $page <= 1 ? 1 : $page;
        $total = $total <= 0 ? 0 : $total;
        $limit = $limit <= 1 ? 1 : $limit;

        $pages = ceil($total / $limit);
        $page = $page > $pages ? $pages : $page;

        $paginate = new \stdClass;
        $paginate->items = $items;
        $paginate->current = $page;
        $paginate->before = ($page - 1) < 1 ? 1 : ($page - 1);
        $paginate->first = 1;
        $paginate->next = ($page + 1) > $pages ? $pages : ($page + 1);
        $paginate->last = $pages;

        $paginate->total_pages = $pages;
        $paginate->total_items = $total;

        return $paginate;
    }
}
