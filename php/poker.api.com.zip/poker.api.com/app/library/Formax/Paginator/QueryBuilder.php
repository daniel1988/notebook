<?php

namespace Formax\Paginator;

class QueryBuilder extends \Phalcon\Paginator\Adapter\QueryBuilder
{

    public function getPaginate()
    {
        $builder = clone $this->_builder;

        $totalBuilder = clone $this->_builder;

        $limit = $this->_limitRows;
        $numberPage = (int) $this->_page;

        if ($numberPage < 1) {
            $numberPage = 1;
        }

        $number = $limit * ($numberPage - 1);
        if ($number < $limit) {
            $builder->limit($limit);
        } else {
            $builder->limit($limit, $number);
        }

        // 解决 query builder 中存在 group by 时的统计不准确的 bug
        // @link https://github.com/phalcon/cphalcon/issues/2411
        if ($group = $totalBuilder->getGroupBy()) {
            $totalBuilder->columns('COUNT(DISTINCT ' . $group . ') AS rowcount')->groupBy(null);
        } else {
            $totalBuilder->columns('COUNT(*) as rowcount');
        }

        // COUNT不需要 ORDER BY
        $totalBuilder->orderBy(null);

        $rowCount = (int) $totalBuilder->getQuery()->execute()->getFirst()->rowcount;
        $totalPages = (int) ceil($rowCount / $limit);

        $paginate = new \stdClass;
        $paginate->items = $builder->getQuery()->execute();
        $paginate->first = 1;
        $paginate->before = $numberPage == 1 ? 1 : $numberPage - 1;
        $paginate->current = $numberPage;
        $paginate->last = $totalPages;
        $paginate->next = $numberPage < $totalPages ? $numberPage + 1 : $totalPages;
        $paginate->total_pages = $totalPages;
        $paginate->total_items = $rowCount;
        $paginate->limit = $limit;

        return $paginate;
    }
}
