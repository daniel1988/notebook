<?php

namespace Formax\Paginator;

class Exception extends \Exception
{}
