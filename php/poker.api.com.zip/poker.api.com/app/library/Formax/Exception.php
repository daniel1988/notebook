<?php

namespace Formax;

class Exception extends \Exception
{}
