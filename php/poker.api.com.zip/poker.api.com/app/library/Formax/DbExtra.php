<?php

namespace Formax;

/**
 * DB 扩展，主要用于 cli 模式下快速对数据进行操作
 */
class DbExtra
{

    protected static $message = null;

    /**
     * 获取连接
     *
     * @param  mixed                     $connection
     * @return \Phalcon\Db\Adapter\Pdo
     */
    public static function connection($connection = null)
    {
        if ($connection === null) {
            return S('db');
        }

        if (is_string($connection)) {
            return S($connection);
        }

        if ($connection instanceof \Phalcon\Db\Adapter\Pdo) {
            return $connection;
        }

        throw new Exception('Invalid database connection');
    }

    /**
     * 对值添加单引号
     *
     * @param  mixed    $value
     * @return string
     */
    public static function quoteValue($value)
    {
        if (is_bool($value)) {
            return (int) $value;
        } elseif (is_int($value) || is_float($value)) {
            return $value;
        } elseif (is_array($value)) {
            $value = implode(',', $value);
        }

        return "'" . str_replace("'", "\'", $value) . "'";
    }

    /**
     * 执行数据库初始化
     *
     * @param  string   $dbname
     * @param  string   $timezone
     * @param  mixed    $connection
     * @return string
     */
    public static function init($dbname, $timezone = '+8:00', $connection = null)
    {
        self::execute("use $dbname", $connection);
        self::execute("set time_zone = '$timezone'", $connection);
    }

    /**
     * 执行原生 sql
     *
     * @param  string    $rawSql
     * @param  mixed     $connection
     * @return boolean
     */
    public static function execute($rawSql, $connection = null)
    {
        // 重置错误消息
        self::$message = null;

        // try {
        return self::connection($connection)->execute($rawSql);
        // } catch (\PDOException $e) {
        // self::$message = $e->getMessage();

        // return false;
        // }
    }

    /**
     * 获取当前 execute 操作的错误消息
     *
     * @return string
     */
    public static function message()
    {
        return self::$message;
    }

    /**
     * 执行写入操作 (INSERT INTO ...)
     *
     * @param  string    $table
     * @param  array     $data
     * @param  mixed     $connection
     * @return boolean
     */
    public static function insert($table, array $data, $connection = null)
    {
        foreach ($data as $key => &$val) {
            $val = self::quoteValue($val);
        }

        $columns = implode(', ', array_keys($data));
        $values = implode(', ', array_values($data));
        $sql = "INSERT INTO $table ($columns) VALUES ($values)";

        return self::execute($sql, $connection);
    }

    /**
     * 执行替换操作 (REPLACE INTO ..., only mysql)
     *
     * @param  string    $table
     * @param  array     $data
     * @param  mixed     $connection
     * @return boolean
     */
    public static function replace($table, array $data, $connection = null)
    {
        foreach ($data as $key => &$val) {
            $val = self::quoteValue($val);
        }

        $columns = implode(', ', array_keys($data));
        $values = implode(', ', array_values($data));
        $sql = "REPLACE INTO $table ($columns) VALUES ($values)";

        return self::execute($sql, $connection);
    }

    /**
     * 执行更新操作 (UPDATE ... SET ...)
     *
     * @param  string    $table
     * @param  array     $data
     * @param  mixed     $where
     * @param  mixed     $connection
     * @return boolean
     */
    public static function update($table, array $data, $where = null, $connection = null)
    {
        $set = [];
        foreach ($data as $key => $val) {
            $set[] = "$key=" . self::quoteValue($val);
        }

        $sql = "UPDATE $table SET " . implode(', ', $set);
        if ($where !== null) {
            $sql .= ' WHERE ' . (is_string($where) ? $where : implode(' AND ', $where));
        }

        return self::execute($sql, $connection);
    }

    /**
     * 执行删除操作 (DELETE FROM ...)
     *
     * @param  string    $table
     * @param  mixed     $where
     * @param  mixed     $connection
     * @return boolean
     */
    public static function delete($table, $where = null, $connection = null)
    {
        $sql = "DELETE FROM $table";

        if ($where !== null) {
            $sql .= ' WHERE ' . (is_string($where) ? $where : implode(' AND ', $where));
        }

        return self::execute($sql, $connection);
    }

    /**
     * 上一条 replase/insert/update/delete 影响的记录数
     *
     * @param  mixed     $connection
     * @return integer
     */
    public static function affectedRows($connection = null)
    {
        return self::connection($connection)->affectedRows();
    }

    /**
     * 统计记录数
     *
     * @param  string    $table
     * @param  string    $column
     * @param  mixed     $where
     * @param  mixed     $connection
     * @return integer
     */
    public static function count($table, $where = null, $column = '*', $connection = null)
    {
        is_null($column) && $column = '*';

        $sql = "SELECT COUNT($column) FROM $table";

        if ($where !== null) {
            $sql .= ' WHERE ' . (is_string($where) ? $where : implode(' AND ', $where));
        }

        return (int) self::fetchColumn($sql, 0, $connection);
    }

    /**
     * 以数组的形式返回所有的记录
     *
     * @param  string  $sql
     * @param  mixed   $connection
     * @return array
     */
    public static function fetchAll($sql, $connection = null)
    {
        return self::connection($connection)->fetchAll($sql, \Phalcon\Db::FETCH_ASSOC);
    }

    /**
     * 以对象的形式返回所有的记录
     *
     * @param  string   $sql
     * @param  mixed    $connection
     * @return object
     */
    public static function fetchObj($sql, $connection = null)
    {
        return self::connection($connection)->fetchAll($sql, \Phalcon\Db::FETCH_OBJ);
    }

    /**
     * 返回结果集中第一行的数据
     *
     * @param  string  $sql
     * @param  mixed   $connection
     * @return array
     */
    public static function fetchRow($sql, $connection = null)
    {
        return self::connection($connection)->fetchOne($sql, \Phalcon\Db::FETCH_ASSOC);
    }

    /**
     * 返回结果集中第一行指定列的数据
     *
     * @param  string  $sql
     * @param  mixed   $connection
     * @return mixed
     */
    public static function fetchColumn($sql, $column = 0, $connection = null)
    {
        $data = self::connection($connection)->fetchOne($sql, \Phalcon\Db::FETCH_BOTH);

        return isset($data[$column]) ? $data[$column] : null;
    }

    /**
     * 返回结果集中第一行第一列的数据
     *
     * @param  string  $sql
     * @param  mixed   $connection
     * @return mixed
     */
    public static function fetchFirst($sql, $connection = null)
    {
        return self::fetchColumn($sql, 0, $connection);
    }

    /**
     * 上一条 insert 写入的 id
     *
     * @param  mixed   $connection
     * @return mixed
     */
    public static function lastInsertId($connection = null)
    {
        return self::connection($connection)->lastInsertId();
    }
}
