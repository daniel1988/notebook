<?php

namespace Formax;

/**
 * 密码 HASH 处理
 */
class Password
{

    /**
     * 密码哈希盐模
     *
     * @var array
     */
    public static $pattern = [1, 3, 5, 9, 14, 15, 20, 21, 28, 30];

    /**
     * 密码哈希加密方法
     *
     * @var string
     */
    public static $method = 'sha1';

    /**
     * 查找 salt
     *
     * @param  string   $password
     * @return string
     */
    public static function salt($password)
    {
        $salt = '';
        $pattern = self::$pattern;

        foreach ($pattern as $i => $offset) {
            // Find salt characters, take a good long look...
            $salt .= substr($password, $offset + $i, 1);
        }

        return $salt;
    }

    /**
     * 创建密码
     *
     * @param  string   $password
     * @param  boolean  $salt
     * @return string
     */
    public static function create($password, $salt = false)
    {
        if ($salt === false) {
            // Create a salt seed, same length as the number of offsets in the pattern
            $salt = substr(hash('sha1', uniqid(null, true)), 0, count(self::$pattern));
        }

        // Password hash that the salt will be inserted into
        $hash = self::hash($salt . $password);

        // Change salt to an array
        $salt = str_split($salt, 1);

        // Returned password
        $password = '';

        // Used to calculate the length of splits
        $last_offset = 0;

        foreach (self::$pattern as $offset) {
            // Split a new part of the hash off
            $part = substr($hash, 0, $offset - $last_offset);

            // Cut the current part out of the hash
            $hash = substr($hash, $offset - $last_offset);

            // Add the part to the password, appending the salt character
            $password .= $part . array_shift($salt);

            // Set the last offset to the current offset
            $last_offset = $offset;
        }

        // Return the password, with the remaining hash appended
        return $password . $hash;
    }

    /**
     * Perform a hash, using the configured method.
     *
     * @param  string   $str
     * @return string
     */
    public static function hash($str)
    {
        return hash(self::$method, $str);
    }

    /**
     * 比较密码是否一致
     *
     * @param string $input
     * @param string $password
     */
    public static function match($input, $password)
    {
        return (self::create($input, self::salt($password)) === $password);
    }
}
