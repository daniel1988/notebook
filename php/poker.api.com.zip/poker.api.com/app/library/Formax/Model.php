<?php

namespace Formax;

use Phalcon\Db\RawValue;
use Phalcon\Mvc\Model as PhalconModel;
use Phalcon\Mvc\Model\Message;
use Phalcon\Mvc\Model\Query\Builder;

/**
 * 基础 Model 实现
 *
 * @link  http://docs.phalconphp.com/zh/latest/reference/models.html
 * @link  http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Model.html
 */
class Model extends PhalconModel
{
    /**
     * @var array
     */
    protected static $instances = [];

    /**
     * 被禁用的事件
     *
     * @var array
     */
    public $_disableEvents = [];

    /**
     * 初始化方法
     */
    public function initialize()
    {
        self::setup([
            'notNullValidations' => false, // 禁止非空验证
        ]);

        /**
         * 动态更新
         *
         * 此功能允许ORM在创建SQL UPDATE语句时，只改变有改变的字段，而不是整个表的所有字段。
         * 在某些情况下，这可以提高性能，减少应用程序与数据库服务器之间的传输数据量
         */
        $this->useDynamicUpdate(true);

        /**
         * 记录快照
         *
         * 这项新功能，指定的Models可以设定为查询时保持记录的快照。
         * 你可以使用此功能来实现审计或只是为了知道哪些字段被更改过：
         *
         *     $robot = new Robots();
         *     $robot->name = 'Other name';
         *     var_dump($robot->getChangedFields()); // ['name']
         *     var_dump($robot->hasChanged('name')); // true
         */
        $this->keepSnapshots(true);
    }

    /**
     * 在执行 create 方法前触发该事件
     * 返回 false 时停止执行 create
     *
     * @return boolean
     */
    public function beforeSave()
    {
        if (isset($this->ctime) && !$this->ctime) {
            $this->ctime = time();
        }

        if (isset($this->mtime)) {
            $this->mtime = time();
        }

        return true;
    }

    /**
     * 生成一个错误消息，并返回 false
     *
     * @param  string  $message 消息内容
     * @param  string  $field   错误字体
     * @param  string  $type    错误类型
     * @return false
     */
    public function error($message, $field = null, $type = null)
    {
        $this->appendMessage(new Message(__($message), $field, $type));

        return false;
    }

    /**
     * 获得第一条错误消息
     *
     * @return string
     */
    public function getMessage()
    {
        return $this->getFirstMessage();
    }

    /**
     * 获得第一条错误消息
     *
     * @return string
     */
    public function getFirstMessage()
    {
        if (count($this->getMessages())) {
            return (string) current($this->getMessages());
        }

        return false;
    }

    /**
     * 获取最后一条错误消息
     *
     * @return string
     */
    public function getLastMessage()
    {
        if (count($this->getMessages())) {
            return (string) end($this->getMessages());
        }

        return false;
    }

    /**
     * Find method overload.
     * Get entities according to some condition.
     *
     * @param  string                            $condition Condition string.
     * @param  array                             $params    Condition params.
     * @param  string|null                       $order     Order by field name.
     * @param  string|null                       $limit     Selection limit.
     * @return PhalconModel\ResultsetInterface
     */
    public static function get($condition, array $params, $order = null, $limit = null)
    {
        $condition = vsprintf($condition, $params);
        $parameters = [$condition];

        if ($order) {
            $parameters['order'] = $order;
        }

        if ($limit) {
            $parameters['limit'] = $limit;
        }

        return self::find($parameters);
    }

    /**
     * FindFirst method overload.
     * Get entity according to some condition.
     *
     * @param  string          $condition Condition string.
     * @param  array           $params    Condition params.
     * @param  string|null     $order     Order by field name.
     * @return AbstractModel
     */
    public static function getFirst($condition, array $params, $order = null)
    {
        $condition = vsprintf($condition, $params);
        $parameters = [$condition];

        if ($order) {
            $parameters['order'] = $order;
        }

        return self::findFirst($parameters);
    }

    /**
     * Get identity.
     *
     * @return mixed
     */
    public function getId()
    {
        if (property_exists($this, 'id')) {
            return $this->id;
        }

        $primaryKeys = $this->getDI()->get('modelsMetadata')->getPrimaryKeyAttributes($this);

        switch (count($primaryKeys)) {
            case 0:
                return null;
                break;
            case 1:
                return $this->{$primaryKeys[0]};
                break;
            default:
                return array_intersect_key(
                    get_object_vars($this),
                    array_flip($primaryKeys)
                );
        }
    }

    /**
     * 创建一个查询 builder
     *
     * @link   http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Model_Query_Builder.html
     *
     * @return \Phalcon\Mvc\Model\Query\Builder
     */
    public static function createBuilder($alias = 'self')
    {
        return self::instance()
            ->getModelsManager()
            ->createBuilder()
            ->addFrom(get_called_class(), $alias);
    }

    /**
     * 获取单例实例
     *
     * @return \Formax\Model
     */
    public static function instance()
    {
        $class = get_called_class();

        if (!isset(self::$instances[$class])) {
            self::$instances[$class] = new $class;
        }

        return self::$instances[$class];

        return new $class;
    }

    /**
     * 是否启用 validation 方法
     *
     * @param  boolean         useValidation
     * @return \Formax\Model
     */
    public function useValidation($useValidation = true)
    {
        $events = [
            'beforeValidation',
            'beforeValidationOnCreate',
            'beforeValidationOnUpdate',
            'validation',
            'afterValidationOnCreate',
            'afterValidationOnUpdate',
            'afterValidation',
        ];

        $useValidation ? $this->enableEvents($events) : $this->disableEvents($events);

        return $this;
    }

    /**
     * 禁用事件
     *
     * @param  array|string    $events
     * @return \Formax\Model
     */
    public function disableEvents($events)
    {
        is_array($events) || $events = [$events];

        $this->_disableEvents += array_map('strtolower', $events);

        return $this;
    }

    /**
     * 启用事件
     *
     * @param  array|string    $events
     * @return \Formax\Model
     */
    public function enableEvents($events)
    {
        is_array($events) || $events = [$events];

        $events = array_map('strtolower', $events);

        foreach ($this->_disableEvents as $index => $eventName) {
            if (in_array($eventName, $events)) {
                unset($this->_disableEvents[$index]);
            }
        }

        return $this;
    }

    // --------------------------------------
    // 以下方法重载框架原生的方法
    // --------------------------------------

    /**
     * Fires an event, implicitly calls behaviors and listeners in the events manager are notified
     *
     * @param  string    $eventName
     * @return boolean
     */
    public function fireEvent($eventName)
    {
        $eventName = strtolower($eventName);

        $this->_beforeFireEvent($eventName);

        $result = in_array($eventName, $this->_disableEvents) ? true : parent::fireEventCancel($eventName);

        $this->_afterFireEvent($eventName);

        return $result;
    }

    /**
     * Fires an event, implicitly calls behaviors and listeners in the events manager are notified
     * This method stops if one of the callbacks/listeners returns boolean false
     *
     * @param  string    $eventName
     * @return boolean
     */
    public function fireEventCancel($eventName)
    {
        $eventName = strtolower($eventName);

        $this->_beforeFireEvent($eventName);

        $result = in_array($eventName, $this->_disableEvents) ? true : parent::fireEventCancel($eventName);

        $this->_afterFireEvent($eventName);

        return $result;
    }

    /**
     * 在事件执行前调用
     *
     * @param string $eventName
     */
    protected function _beforeFireEvent($eventName)
    {
        /**
         * validation 事件在整个 model 中，只会被 _preSave() 方法调用
         * not null 的验证将在 validation 事件前执行，因此可以在 validation 执行前将空值还原
         *
         * @link https://github.com/phalcon/cphalcon/blob/master/ext/mvc/model.c#L3252
         */
        if ('validation' === $eventName) {
            foreach ($this->toArray() as $key => $val) {
                // 修正空值转换后数据为 Phalcon\Db\RawValue 实例的问题
                if ($val instanceof RawValue) {
                    $this->$key = $val->__toString() === "''" ? '' : $val->__toString();
                }
            }
        }
    }

    /**
     * 在事件被执行后调用
     *
     * @param string $eventName
     */
    protected function _afterFireEvent($eventName)
    {
        /**
         * beforeValidationOnCreate / beforeValidationOnUpdate 事件在整个 model 中，只会被 _preSave() 方法调用
         * 执行该事件后，即会执行 not null 验证，在此之前对空值做转换
         *
         * @link https://github.com/phalcon/cphalcon/blob/master/ext/mvc/model.c#L3085
         */
        if ('beforevalidationoncreate' === $eventName || 'beforevalidationonupdate' === $eventName) {
            foreach ($this->toArray() as $key => $value) {
                if (isset($this->{$key}) && '' === $this->{$key}) {
                    // 将为空的值，转换为空值
                    $this->{$key} = new RawValue("''");
                }
            }
        }
    }

    /**
     * Allows to count how many records match the specified conditions
     *
     * @param  array     parameters
     * @return integer
     */
    public static function count($parameters = null)
    {
        return (int) parent::count($parameters);
    }

    /**
     * Allows to calculate a summatory on a column that match the specified conditions
     *
     * @param  array   parameters
     * @return float
     */
    public static function sum($parameters = null)
    {
        return (float) parent::sum($parameters);
    }

    /**
     * Allows to calculate the average value on a column matching the specified conditions
     *
     * @param  array   parameters
     * @return float
     */
    public static function average($parameters = null)
    {
        return (float) parent::average($parameters);
    }
}
