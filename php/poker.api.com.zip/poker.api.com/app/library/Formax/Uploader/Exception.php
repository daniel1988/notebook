<?php

namespace Formax\Uploader;

class Exception extends \Exception
{}
