<?php

namespace Formax;

use CRM\UserRoles;
use Phalcon\Session\Bag as SessionBag;

class Auth
{

    /**
     * Session 数据存储命名空间
     *
     * @var \Phalcon\Session\Bag
     */
    protected $_storage = null;

    /**
     * 已登录的用户信息
     *
     * @var \stdClass
     */
    protected $_user = false;

    /**
     * 构造方法
     */
    public function __construct()
    {
        $this->_storage = new SessionBag(__CLASS__);
        $this->_storage->initialize();
        S('i18n')->import('auth');
    }

    /**
     * 获取 session bag 数据
     *
     * @return \Phalcon\Session\Bag
     */
    public function getStorage()
    {
        return $this->_storage;
    }

    /**
     * 判断是否登录
     *
     * @return boolean
     */
    public function isLogined()
    {
        return $this->_storage->logined === true;
    }

    /**
     * 用户登录
     *
     * @param  \stdClass           $user
     * @throws \Formax\Exception
     * @return \Formax\Auth
     */
    public function loginSuccess($user)
    {
        // 完成登录信息
        $this->_compleLogin($user);

        // 更新登录日志
        $this->_updateLoginLogs($user->user_id);
    }

    /**
     * 退出登录
     */
    public function logout()
    {
        $this->_storage->destroy();

        // 退出登录时销毁所有 session，避免 session 冲突
        S('session')->destroy();
    }

    /**
     * 获取已经存储的用户信息
     *
     * @param  string   $key
     * @return string
     */
    public function __get($key)
    {
        return $this->_storage->get($key);
    }

    /**
     * 获取所有的用户信息
     *
     * @return array
     */
    public function toArray()
    {
        return $this->_storage->getIterator()->getArrayCopy();
    }

    /**
     * 已登录用户，更新登录信息
     */
    public function refresh()
    {
        if ($this->_storage->user_id) {
            $this->_compleLogin($this->getUser());
        }
    }

    /**
     * 获取用户信息
     *
     * @throws \Formax\Exception
     * @return \stdClass
     */
    public function getUser()
    {
        if (!$this->_user && $this->_storage->user_id) {
            $this->_user = S('oapi')->user->get($this->_storage->user_id);
        }

        return $this->_user;
    }

    /**
     * 获取用户角色数据
     *
     * @return array
     */
    public function getUserRoles()
    {
        $user = $this->getUser();

        return $user ? UserRoles::getRoles($this->user_id, 'role_id') : [];
    }

    /**
     * 完成登录信息
     *
     * @param object $user
     */
    protected function _compleLogin($user)
    {
        $this->_user = $user;

        $data = [
            'logined' => true,
            'user_id' => (int) $user->user_id,
            'email' => $user->email,
            'realname' => $user->realname,
            'last_ip' => $user->last_ip,
            'last_time' => $user->last_time,
            'status' => (int) $user->status,
            'creator' => (int) $user->creator,
            'failures' => 0,
        ];

        foreach ($data as $key => $value) {
            $this->_storage->set($key, $value);
        }
    }

    /**
     * 更新会员登录日志信息
     *
     * @param integer $user_id
     */
    protected function _updateLoginLogs($user_id) {}
}
