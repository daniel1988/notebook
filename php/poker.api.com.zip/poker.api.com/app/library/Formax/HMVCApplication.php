<?php
namespace Formax;

use Phalcon\DiInterface;
use Phalcon\Http\ResponseInterface;
use Phalcon\Mvc\Application as MVCApplication;

/**
 * 构造一个 hmvc appication
 *
 * @link http://docs.phalconphp.com/zh/latest/reference/applications.html
 * @link http://docs.phalconphp.com/zh/latest/api/Phalcon_Mvc_Application.html
 * @link https://github.com/phalcon/mvc/tree/master/hmvc
 */
class HMVCApplication extends MVCApplication
{

    /**
     * HMVCApplication Constructor
     *
     * @param Phalcon\DiInterface
     */
    public function __construct(DiInterface $di)
    {
        // Register the app itself as a service
        $di['app'] = $this;

        // Sets the parent Id
        parent::setDI($di);
    }

    /**
     * Does a HMVC request in the application
     *
     * @param  array   $location
     * @param  array   $data
     * @return mixed
     */
    public function request($location, $data = null)
    {
        $dispatcher = clone $this->getDI()->get('dispatcher');

        if (isset($location['controller'])) {
            $dispatcher->setControllerName($location['controller']);
        } else {
            $dispatcher->setControllerName('index');
        }

        if (isset($location['action'])) {
            $dispatcher->setActionName($location['action']);
        } else {
            $dispatcher->setActionName('index');
        }

        if (isset($location['params'])) {
            if (is_array($location['params'])) {
                $dispatcher->setParams($location['params']);
            } else {
                $dispatcher->setParams((array) $location['params']);
            }
        } else {
            $dispatcher->setParams([]);
        }

        $dispatcher->dispatch();

        $response = $dispatcher->getReturnedValue();
        if ($response instanceof ResponseInterface) {
            return $response->getContent();
        }

        return $response;
    }
}
