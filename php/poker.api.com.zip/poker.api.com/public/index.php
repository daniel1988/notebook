<?php

/**
 * 默认时区定义
 */
date_default_timezone_set('Asia/Shanghai');

/**
 * 设置错误报告模式
 */
error_reporting(E_ALL);

/**
 * 设置默认区域
 */
setlocale(LC_ALL, 'zh_CN.utf-8');

/**
 * 设置内部字符默认编码为 UTF-8
 */
mb_internal_encoding('UTF-8');

/**
 * 检测框架是否安装
 */
if (!extension_loaded('phalcon')) {
    exit('Phalcon framework extension is not installed');
}

/**
 * 检测 PDO_MYSQL
 */
if (!extension_loaded('pdo_mysql')) {
    exit('PDO_MYSQL extension is not installed');
}


/**
 * 定义项目根目录
 */
define('ROOT_PATH', dirname(__DIR__));

/**
 * Include defined constants
 */
require ROOT_PATH . '/app/bootstrap/defined.php';

/**
 * 打开/关闭错误显示
 * 在 OA 系统中显示错误
 */
ini_set('display_errors', true);

/**
 * 避免 cli 或 curl 模式下 xdebug 输出 html 调试信息
 */
if (IS_CLI || IS_CURL) {
    ini_set('html_errors', false);
}

/**
 * Include the common functions
 */
require APP_PATH . '/functions/common.php';

/**
 * Include the basis functions
 */
load_functions('array', 'string', 'url', 'valid', 'application', 'alias', 'view', 'tag', 'time');

/**
 * Read the configuration
 */
if (!$config = config('application')) {
    exit('Application configuration failed to load');
}

/**
 * Read auto-loader
 */
include APP_PATH . '/bootstrap/loader.php';

/**
 * Read services
 */
include APP_PATH . '/bootstrap/services.php';

/**
 * Handle the request
 */
$application = new Phalcon\Mvc\Application($di);

/**
 * 获取输出内容
 */
try {
    echo $application->handle()->getContent();
} catch (PDOException $e) {
    $message = sprintf(
        '%s [%d]: %s (in %s on line %d)\n',
        get_class($e),
        $e->getCode(),
        $e->getMessage(),
        $e->getFile(),
        $e->getLine()
    );

    if (PRODUCTION) {
        die('DATABASE ERROR!');
    } else {
        die($message);
    }
}
